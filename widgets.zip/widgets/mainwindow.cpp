#include "mainwindow.h"

#include <QMenuBar>
#include <QMenu>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QStandardItem>
#include <QLabel>
#include <QString>
#include <QVariantMap>
#include <QDebug>
//#include <QAbstractScrollArea>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    createTreeView();
    createTabWidget();

    // добавляю горизонтальный разделитель
    QSplitter *splitter = new QSplitter(Qt::Horizontal, this);
    splitter->addWidget(treeView);
    splitter->addWidget(tabWidget);
    splitter->setStretchFactor(1, 1);
    splitter->setCollapsible(0, false);
    splitter->setCollapsible(1, false);

    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);
    layout->addWidget(splitter);
    setCentralWidget(centralWidget);

    // подключаем слот к сигналу clicked дерева
//   connect(treeView, &QTreeView::clicked, this, &MainWindow::onTreeViewItemClicked);
    connect( treeView, SIGNAL( clicked(QModelIndex)),
            this, SLOT( onTreeViewItemClicked(QModelIndex))
             );

    setModel( vfvpmodel );

}

MainWindow::~MainWindow()
{
}


void MainWindow::createTreeView()
{
    // добавляю дерево списков
    model = new QStandardItemModel(this);
    QStandardItem *rootItem = model->invisibleRootItem();

    QStandardItem *item1 = new QStandardItem("Текст 1");
    // пример
    item1->setData( "item1", Qt::UserRole );
    rootItem->appendRow(item1);

    QStandardItem *item1_1 = new QStandardItem("Вложенный текст");
    item1->appendRow(item1_1);
    /// вложение во вложение в Текст 1 если нужно
//    QStandardItem *item3 = new QStandardItem(tr("Перевложенный текст"));
//    item1->appendRow(item3);
    QStandardItem *item2 = new QStandardItem("Текст 2");
    rootItem->appendRow(item2);
    QStandardItem *item3 = new QStandardItem("Текст 3");
    rootItem->appendRow(item3);

    treeView = new QTreeView(this);
    treeView->setModel(model);
    treeView->setHeaderHidden(true);
    treeView->setSelectionMode(QAbstractItemView::SingleSelection);
}

void MainWindow::createTabWidget()
{
    // добавляю вкладки
    tabWidget = new QTabWidget(this);

//    // добавляем вертикальную прокрутку к виджету вкладок
//       scrollArea = new QScrollArea(tabWidget);
//       scrollArea->setWidgetResizable(true);
//       scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//       scrollArea->setFrameShape(QFrame::NoFrame);
//       scrollArea->setWidget(tabWidget);

    tab1 = new QWidget(tabWidget);
//    tab1->setObjectName(QString::fromUtf8("tab1"));
//    verticalScrollBar = new QScrollBar(tab1);
//    verticalScrollBar->setObjectName(QString::fromUtf8("verticalScrollBar"));
//    verticalScrollBar->setGeometry(QRect(600, 0, 16, 541));
//    verticalScrollBar->setOrientation(Qt::Vertical);
    tab2 = new QWidget(tabWidget);
    tab3 = new QWidget(tabWidget);
    tab4 = new QWidget(tabWidget);
    tab5 = new QWidget(tabWidget);

    tabWidget->addTab(tab1, ("Tab1"));
    tabWidget->addTab(tab2, ("Tab 2"));
    tabWidget->addTab(tab3, ("Tab 3"));
    tabWidget->addTab(tab4, ("Tab 4"));
    tabWidget->addTab(tab5, ("Tab 5"));

    // добавляем QScrollArea для вертикального скроллинга
        QScrollArea* scrollArea = new QScrollArea(tab1);
        scrollArea->setWidgetResizable(true);
        tab1->setLayout(new QVBoxLayout(tab1));
        tab1->layout()->addWidget(scrollArea);

        // добавляем текстовые поля в QScrollArea
//            QWidget* scrollWidget = new QWidget(scrollArea);
//            scrollWidget->setLayout(new QVBoxLayout(scrollWidget));
//            scrollArea->setWidget(scrollWidget);

            QWidget *scrollWidget = new QWidget(scrollArea);
            scrollArea->setWidget(scrollWidget);

            QVBoxLayout *scrollLayout = new QVBoxLayout(scrollWidget);
            scrollWidget->setLayout(scrollLayout);

            textTab1Edit1 = new QTextEdit(scrollWidget);
            textTab1Edit1->setObjectName("TextEdit1Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit1);
            textTab1Edit2 = new QTextEdit(scrollWidget);
            textTab1Edit2->setObjectName("TextEdit2Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit2);
            textTab1Edit3 = new QTextEdit(scrollWidget);
            textTab1Edit3->setObjectName("TextEdit3Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit3);
            textTab1Edit4 = new QTextEdit(scrollWidget);
            textTab1Edit4->setObjectName("TextEdit4Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit4);
            textTab1Edit5 = new QTextEdit(scrollWidget);
            textTab1Edit5->setObjectName("TextEdit5Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit5);
            textTab1Edit6 = new QTextEdit(scrollWidget);
            textTab1Edit6->setObjectName("TextEdit6Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit6);
            textTab1Edit7 = new QTextEdit(scrollWidget);
            textTab1Edit7->setObjectName("TextEdit7Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit7);
            textTab1Edit8 = new QTextEdit(scrollWidget);
            textTab1Edit8->setObjectName("TextEdit8Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit8);
            textTab1Edit9 = new QTextEdit(scrollWidget);
            textTab1Edit9->setObjectName("TextEdit9Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit9);
            textTab1Edit10 = new QTextEdit(scrollWidget);
            textTab1Edit10->setObjectName("TextEdit10Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit10);
            textTab1Edit11 = new QTextEdit(scrollWidget);
            textTab1Edit11->setObjectName("TextEdit11Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit11);
            textTab1Edit12 = new QTextEdit(scrollWidget);
            textTab1Edit12->setObjectName("TextEdit12Tab1");

//    QVBoxLayout *tab1Layout = new QVBoxLayout(tab1);
//   textTab1Edit1 = new QTextEdit(tab1);
//   textTab1Edit1->setObjectName("TextEdit1Tab1");
//  // textTab1Edit1->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit2 = new QTextEdit(tab1);
//   textTab1Edit2->setObjectName("TextEdit2Tab1");
//   //textTab1Edit2->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit3 = new QTextEdit(tab1);
//   textTab1Edit3->setObjectName("TextEdit3Tab1");
//   //textTab1Edit3->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit4 = new QTextEdit(tab1);
//   textTab1Edit4->setObjectName("TextEdit4Tab1");
//  // textTab1Edit4->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit5 = new QTextEdit(tab1);
//   textTab1Edit5->setObjectName("TextEdit5Tab1");
//  // textTab1Edit5->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit6 = new QTextEdit(tab1);
//   textTab1Edit6->setObjectName("TextEdit6Tab1");
//  // textTab1Edit6->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit7 = new QTextEdit(tab1);
//   textTab1Edit7->setObjectName("TextEdit7Tab1");
//   //textTab1Edit7->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit8 = new QTextEdit(tab1);
//   textTab1Edit8->setObjectName("TextEdit8Tab1");
//  // textTab1Edit8->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit9 = new QTextEdit(tab1);
//   textTab1Edit9->setObjectName("TextEdit9Tab1");
//   textTab1Edit10 = new QTextEdit(tab1);
//   textTab1Edit10->setObjectName("TextEdit10Tab1");
//   textTab1Edit11 = new QTextEdit(tab1);
//   textTab1Edit11->setObjectName("TextEdit11Tab1");
//   textTab1Edit12 = new QTextEdit(tab1);
//   textTab1Edit12->setObjectName("TextEdit12Tab1");
//   textTab1Edit13 = new QTextEdit(tab1);
//   textTab1Edit13->setObjectName("TextEdit13Tab1");
//   textTab1Edit14 = new QTextEdit(tab1);
//   textTab1Edit14->setObjectName("TextEdit14Tab1");
//   textTab1Edit15 = new QTextEdit(tab1);
//   textTab1Edit15->setObjectName("TextEdit15Tab1");
//   textTab1Edit16 = new QTextEdit(tab1);
//   textTab1Edit16->setObjectName("TextEdit16Tab1");
//   textTab1Edit17 = new QTextEdit(tab1);
//   textTab1Edit17->setObjectName("TextEdit17Tab1");
//   textTab1Edit18 = new QTextEdit(tab1);
//   textTab1Edit18->setObjectName("TextEdit18Tab1");
  // textTab1Edit18->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit19 = new QTextEdit(tab1);
//   textTab1Edit19->setObjectName("TextEdit19Tab1");
//   textTab1Edit20 = new QTextEdit(tab1);
//   textTab1Edit20->setObjectName("TextEdit20Tab1");
//   textTab1Edit21 = new QTextEdit(tab1);
//   textTab1Edit21->setObjectName("TextEdit21Tab1");
//   textTab1Edit22 = new QTextEdit(tab1);
//   textTab1Edit22->setObjectName("TextEdit22Tab1");
//   textTab1Edit23 = new QTextEdit(tab1);
//   textTab1Edit23->setObjectName("TextEdit23Tab1");
//   textTab1Edit24 = new QTextEdit(tab1);
//   textTab1Edit24->setObjectName("TextEdit24Tab1");
//   textTab1Edit25 = new QTextEdit(tab1);
//   textTab1Edit25->setObjectName("TextEdit25Tab1");
//   textTab1Edit26 = new QTextEdit(tab1);
//   textTab1Edit26->setObjectName("TextEdit26Tab1");
//   textTab1Edit27 = new QTextEdit(tab1);
//   textTab1Edit27->setObjectName("TextEdit27Tab1");
//   textTab1Edit28 = new QTextEdit(tab1);
//   textTab1Edit28->setObjectName("TextEdit28Tab1");
//   textTab1Edit29 = new QTextEdit(tab1);
//   textTab1Edit29->setObjectName("TextEdit29Tab1");

       //QTextEdit* pTeTab1 = new QTextEdit(tab1);
      // pTeTab1->setObjectName("TextEditTab1");

  //  tab1->setLayout( tab1Layout );

  // tab1->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    // добавляю подписи лейблы
            QLabel *labela1Tab1 = new QLabel(("Текст 1:"), scrollWidget);
            scrollLayout->addWidget(labela1Tab1);
            QLabel *labela2Tab1 = new QLabel(("Текст 2:"), scrollWidget);
            scrollLayout->addWidget(labela2Tab1);

            QLabel *labela3Tab1 = new QLabel(("Текст 3:"), scrollWidget);
            scrollLayout->addWidget(labela3Tab1);

            QLabel *labela4Tab1 = new QLabel(("Текст 4:"), scrollWidget);
            scrollLayout->addWidget(labela4Tab1);

            QLabel *labela5Tab1 = new QLabel(("Текст 5:"), scrollWidget);
            scrollLayout->addWidget(labela5Tab1);

            QLabel *labela6Tab1 = new QLabel(("Текст 6:"), scrollWidget);
            scrollLayout->addWidget(labela6Tab1);
            QLabel *labela7Tab1 = new QLabel(("Текст 7:"), scrollWidget);
            scrollLayout->addWidget(labela7Tab1);
            QLabel *labela8Tab1 = new QLabel(("Текст 8:"), scrollWidget);
            scrollLayout->addWidget(labela8Tab1);
            QLabel *labela9Tab1 = new QLabel(("Текст 9:"), scrollWidget);
            scrollLayout->addWidget(labela9Tab1);
            QLabel *labela10Tab1 = new QLabel(("Текст 10:"), scrollWidget);
            scrollLayout->addWidget(labela10Tab1);
            QLabel *labela11Tab1 = new QLabel(("Текст 11:"), scrollWidget);
            scrollLayout->addWidget(labela11Tab1);
            QLabel *labela12Tab1 = new QLabel(("Текст 12:"), scrollWidget);
            scrollLayout->addWidget(labela12Tab1);
//    QLabel *labela1Tab1 = new QLabel(("Текст 1:"), tab1);
//    QLabel *labela2Tab1 = new QLabel(("Текст 2:"), tab1);
//    QLabel *labela3Tab1 = new QLabel(("Текст 3:"), tab1);
//    QLabel *labela4Tab1 = new QLabel(("Текст 4:"), tab1);
//    QLabel *labela5Tab1 = new QLabel(("Текст 5:"), tab1);
//    QLabel *labela6Tab1 = new QLabel(("Текст 6:"), tab1);
//    QLabel *labela7Tab1 = new QLabel(("Текст 7:"), tab1);
//    QLabel *labela8Tab1 = new QLabel(("Текст 8:"), tab1);
//    QLabel *labela9Tab1 = new QLabel(("Текст 9:"), tab1);
//    QLabel *labela10Tab1 = new QLabel(("Текст 10:"), tab1);
//    QLabel *labela11Tab1 = new QLabel(("Текст 11:"), tab1);
//    QLabel *labela12Tab1 = new QLabel(("Текст 12:"), tab1);
//    QLabel *labela13Tab1 = new QLabel(("Текст 13:"), tab1);
//    QLabel *labela14Tab1 = new QLabel(("Текст 14:"), tab1);
//    QLabel *labela15Tab1 = new QLabel(("Текст 15:"), tab1);
//    QLabel *labela16Tab1 = new QLabel(("Текст 16:"), tab1);
//    QLabel *labela17Tab1 = new QLabel(("Текст 17:"), tab1);
//    QLabel *labela18Tab1 = new QLabel(("Текст 18:"), tab1);
//    QLabel *labela19Tab1 = new QLabel(("Текст 19:"), tab1);
//    QLabel *labela20Tab1 = new QLabel(("Текст 20:"), tab1);
//    QLabel *labela21Tab1 = new QLabel(("Текст 21:"), tab1);
//    QLabel *labela22Tab1 = new QLabel(("Текст 22:"), tab1);
//    QLabel *labela23Tab1 = new QLabel(("Текст 23:"), tab1);
//    QLabel *labela24Tab1 = new QLabel(("Текст 24:"), tab1);
//    QLabel *labela25Tab1 = new QLabel(("Текст 25:"), tab1);
//    QLabel *labela26Tab1 = new QLabel(("Текст 26:"), tab1);
//    QLabel *labela27Tab1 = new QLabel(("Текст 27:"), tab1);
//    QLabel *labela28Tab1 = new QLabel(("Текст 28:"), tab1);
//    QLabel *labela29Tab1 = new QLabel(("Текст 29:"), tab1);

//    // делаю поля только для чтения
    textTab1Edit1->setReadOnly(true);
    textTab1Edit2->setReadOnly(true);
    textTab1Edit3->setReadOnly(true);
    textTab1Edit4->setReadOnly(true);
    textTab1Edit5->setReadOnly(true);
    textTab1Edit6->setReadOnly(true);
    textTab1Edit7->setReadOnly(true);
    textTab1Edit8->setReadOnly(true);
    textTab1Edit9->setReadOnly(true);
    textTab1Edit10->setReadOnly(true);
    textTab1Edit11->setReadOnly(true);
    textTab1Edit12->setReadOnly(true);
//    textTab1Edit13->setReadOnly(true);
//    textTab1Edit14->setReadOnly(true);
//    textTab1Edit15->setReadOnly(true);
//    textTab1Edit16->setReadOnly(true);
//    textTab1Edit17->setReadOnly(true);
//    textTab1Edit18->setReadOnly(true);
//    textTab1Edit19->setReadOnly(true);
//    textTab1Edit20->setReadOnly(true);
//    textTab1Edit21->setReadOnly(true);
//    textTab1Edit22->setReadOnly(true);
//    textTab1Edit23->setReadOnly(true);
//    textTab1Edit24->setReadOnly(true);
//    textTab1Edit25->setReadOnly(true);
//    textTab1Edit26->setReadOnly(true);
//    textTab1Edit27->setReadOnly(true);
//    textTab1Edit28->setReadOnly(true);
//    textTab1Edit29->setReadOnly(true);

//    scrollWidget->addWidget(labela1Tab1);
//    scrollWidget->addWidget(textTab1Edit1);
//    tab1Layout->addWidget(labela2Tab1);
//    tab1Layout->addWidget(textTab1Edit2);
//    tab1Layout->addWidget(labela3Tab1);
//    tab1Layout->addWidget(textTab1Edit3);
//    tab1Layout->addWidget(labela4Tab1);
//    tab1Layout->addWidget(textTab1Edit4);
//    tab1Layout->addWidget(labela5Tab1);
//    tab1Layout->addWidget(textTab1Edit5);
//    tab1Layout->addWidget(labela6Tab1);
//    tab1Layout->addWidget(textTab1Edit6);
//    tab1Layout->addWidget(labela7Tab1);
//    tab1Layout->addWidget(textTab1Edit7);
//    tab1Layout->addWidget(labela8Tab1);
//    tab1Layout->addWidget(textTab1Edit8);
//    tab1Layout->addWidget(labela9Tab1);
//    tab1Layout->addWidget(textTab1Edit9);
//    tab1Layout->addWidget(labela10Tab1);
//    tab1Layout->addWidget(textTab1Edit10);
//    tab1Layout->addWidget(labela11Tab1);
//    tab1Layout->addWidget(textTab1Edit11);
//    tab1Layout->addWidget(labela12Tab1);
//    tab1Layout->addWidget(textTab1Edit12);
//    tab1Layout->addWidget(labela13Tab1);
//    tab1Layout->addWidget(textTab1Edit13);
//    tab1Layout->addWidget(labela14Tab1);
//    tab1Layout->addWidget(textTab1Edit14);
//    tab1Layout->addWidget(labela15Tab1);
//    tab1Layout->addWidget(textTab1Edit15);
//    tab1Layout->addWidget(labela16Tab1);
//    tab1Layout->addWidget(textTab1Edit16);
//    tab1Layout->addWidget(labela17Tab1);
//    tab1Layout->addWidget(textTab1Edit17);
//    tab1Layout->addWidget(labela18Tab1);
//    tab1Layout->addWidget(textTab1Edit18);
//    tab1Layout->addWidget(labela19Tab1);
//    tab1Layout->addWidget(textTab1Edit19);
//    tab1Layout->addWidget(labela20Tab1);
//    tab1Layout->addWidget(textTab1Edit20);
//    tab1Layout->addWidget(labela21Tab1);
//    tab1Layout->addWidget(textTab1Edit21);
//    tab1Layout->addWidget(labela22Tab1);
//    tab1Layout->addWidget(textTab1Edit22);
//    tab1Layout->addWidget(labela23Tab1);
//    tab1Layout->addWidget(textTab1Edit23);
//    tab1Layout->addWidget(labela24Tab1);
//    tab1Layout->addWidget(textTab1Edit24);
//    tab1Layout->addWidget(labela25Tab1);
//    tab1Layout->addWidget(textTab1Edit25);
//    tab1Layout->addWidget(labela26Tab1);
//    tab1Layout->addWidget(textTab1Edit26);
//    tab1Layout->addWidget(labela27Tab1);
//    tab1Layout->addWidget(textTab1Edit27);
//    tab1Layout->addWidget(labela28Tab1);
//    tab1Layout->addWidget(textTab1Edit28);
//    tab1Layout->addWidget(labela29Tab1);
//    tab1Layout->addWidget(textTab1Edit29);

//      // tab1Layout->addWidget(pTeTab1);
//    tab1Layout->addStretch(1);



    QVBoxLayout *tab2Layout = new QVBoxLayout(tab2);
//    scrollArea = new QScrollArea(tab2);
//        textTab2Edit1 = new QTextEdit(scrollArea);

    textTab2Edit1 = new QTextEdit(tab2);
    textTab2Edit1->setObjectName("TextEdit1Tab2");
    textTab2Edit2 = new QTextEdit(tab2);
    textTab2Edit2->setObjectName("TextEdit2Tab2");
    textTab2Edit3 = new QTextEdit(tab2);
    textTab2Edit3->setObjectName("TextEdit3Tab2");

//    scrollArea->setWidget(textTab1Edit1);
//       scrollArea->setWidgetResizable(true);
//       scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//       tab1Layout->addWidget(scrollArea);
tab2->setLayout( tab2Layout );


    QLabel *labelb1Tab2 = new QLabel(("Текст 1:"), tab2);
    QLabel *labelb2Tab2 = new QLabel(("Текст 2:"), tab2);
    QLabel *labelb3Tab2 = new QLabel(("Текст 3:"), tab2);

    textTab2Edit1->setReadOnly(true);
    textTab2Edit2->setReadOnly(true);
    textTab2Edit3->setReadOnly(true);

    tab2Layout->addWidget(labelb1Tab2);
    tab2Layout->addWidget(textTab2Edit1);
    tab2Layout->addWidget(labelb2Tab2);
    tab2Layout->addWidget(textTab2Edit2);
    tab2Layout->addWidget(labelb3Tab2);
    tab2Layout->addWidget(textTab2Edit3);

    tab2Layout->addStretch(1);


    QVBoxLayout *tab3Layout = new QVBoxLayout(tab3);
    textTab3Edit1 = new QTextEdit(tab3);
    textTab3Edit1->setObjectName("TextEdit1Tab3");
    textTab3Edit2 = new QTextEdit(tab3);
    textTab3Edit2->setObjectName("TextEdit2Tab3");
    textTab3Edit3 = new QTextEdit(tab3);
    textTab3Edit3->setObjectName("TextEdit3Tab3");


tab3->setLayout( tab3Layout );

    QLabel *labelc1Tab3 = new QLabel(("Текст 1:"), tab3);
    QLabel *labelc2Tab3 = new QLabel(("Текст 2:"), tab3);
    QLabel *labelc3Tab3 = new QLabel(("Текст 3:"), tab3);

    textTab3Edit1->setReadOnly(true);
    textTab3Edit2->setReadOnly(true);
    textTab3Edit3->setReadOnly(true);

    // устанавливаю layouts
    tab3Layout->addWidget(labelc1Tab3);
    tab3Layout->addWidget(textTab3Edit1);
    tab3Layout->addWidget(labelc2Tab3);
    tab3Layout->addWidget(textTab3Edit2);
    tab3Layout->addWidget(labelc3Tab3);
    tab3Layout->addWidget(textTab3Edit3);

    tab3Layout->addStretch(1);

    QVBoxLayout *tab4Layout = new QVBoxLayout(tab4);
    textTab4Edit1 = new QTextEdit(tab4);
    textTab4Edit1->setObjectName("TextEdit1Tab4");
    textTab4Edit2 = new QTextEdit(tab4);
    textTab4Edit2->setObjectName("TextEdit2Tab4");
    textTab4Edit3 = new QTextEdit(tab4);
    textTab4Edit3->setObjectName("TextEdit3Tab4");



tab4->setLayout( tab4Layout );


    QLabel *labelc1Tab4 = new QLabel(("Текст 1:"), tab4);
    QLabel *labelc2Tab4 = new QLabel(("Текст 2:"), tab4);
    QLabel *labelc3Tab4 = new QLabel(("Текст 3:"), tab4);

    textTab4Edit1->setReadOnly(true);
    textTab4Edit2->setReadOnly(true);
    textTab4Edit3->setReadOnly(true);

    // устанавливаю layouts
    tab4Layout->addWidget(labelc1Tab4);
    tab4Layout->addWidget(textTab4Edit1);
    tab4Layout->addWidget(labelc2Tab4);
    tab4Layout->addWidget(textTab4Edit2);
    tab4Layout->addWidget(labelc3Tab4);
    tab4Layout->addWidget(textTab4Edit3);

    tab4Layout->addStretch(1);

    QVBoxLayout *tab5Layout = new QVBoxLayout(tab5);
    textTab5Edit1 = new QTextEdit(tab5);
    textTab5Edit1->setObjectName("TextEdit1Tab5");
    textTab5Edit2 = new QTextEdit(tab5);
    textTab5Edit2->setObjectName("TextEdit2Tab5");
    textTab5Edit3 = new QTextEdit(tab5);
    textTab5Edit3->setObjectName("TextEdit3Tab5");



tab5->setLayout( tab5Layout );

    QLabel *labelc1Tab5 = new QLabel(("Текст 1:"), tab5);
    QLabel *labelc2Tab5 = new QLabel(("Текст 2:"), tab5);
    QLabel *labelc3Tab5 = new QLabel(("Текст 3:"), tab5);

    textTab5Edit1->setReadOnly(true);
    textTab5Edit2->setReadOnly(true);
    textTab5Edit3->setReadOnly(true);

    // устанавливаю layouts
    tab5Layout->addWidget(labelc1Tab5);
    tab5Layout->addWidget(textTab5Edit1);
    tab5Layout->addWidget(labelc2Tab5);
    tab5Layout->addWidget(textTab5Edit2);
    tab5Layout->addWidget(labelc3Tab5);
    tab5Layout->addWidget(textTab5Edit3);

    tab5Layout->addStretch(1);
}

/// задаем модель данных
void MainWindow::setModel( VFVPModel &vfvpmodel )
{
    /// Учетный номер ВФВП
    vfvpmodel.charVfvp.vfvp_kod = "18200000000000040";
    /// Организационно-штатная принадлежность
    vfvpmodel.charVfvp.vfvp_org = "18200000004000040";
    /// Дата и время состояния
    vfvpmodel.charVfvp.vfvp_dt  = QDateTime::currentDateTime();

    POSVFVP posVfvp; /// инициализируем модель данных положения воинского формирования
    /// наименование блока данных координат
    posVfvp.description = QString( "pvfvp" );
    /// геодезическая широта
    posVfvp.latitude    = QString( "56.314014573" );
    /// геодезическая долгота
    posVfvp.longitude   = QString( "42.911885365" );
    /// высота
    posVfvp.height      = QString( "404" );
    /// пояснение
    posVfvp.OK          = QString( "Позиция на высоте 404" );
    /// добавляем модель данных положения воинского формирования в коллекцию
    vfvpmodel.posVfvpLst.append( posVfvp );

    LSVFVP lsVfvp; /// инициализируем модель данных личного состава
    /// наименование блока личного состава
    lsVfvp.description = QString( "личный состав" );
    /// колличество по штату личного состава
    lsVfvp.kolshtat    = QString( "300" );
    /// колличество в наличии личного состава
    lsVfvp.kolnal      = QString( "30" );
    /// укомплектованность личного состава ( на самом деле 10, но так красивее ;-)
    lsVfvp.ukompl      = QString( "3" );
    /// добавляем модель данных личного состава в коллекцию
    vfvpmodel.lsVfvpLst.append( lsVfvp );

    VVTVFVP vvtVfvp; /// инициализируем модель данных ВВТ
    /// наименование блока ВВТ
    vvtVfvp.description = QString( "ВВТ" );
    /// код по классификатору "Конкретные образцы оружия и военной техники"
    vvtVfvp.kkoovt_kod  = QString( "5025200" ); /// М706(V-100) "КОММАНДО"
    /// колличество по штату ВВТ
    vvtVfvp.kolshtat    = QString( "300" );
    /// колличество в наличии ВВТ
    vvtVfvp.kolnal      = QString( "30" );
    /// укомплектованность ВВТ ( ну Вы поняли => 10 )
    vvtVfvp.ukompl      = QString( "3" );
    /// добавляем модель данных ВВТ в коллекцию
    vfvpmodel.vvtVfsvLst.append( vvtVfvp );

    /** пример файла данных ГИС векторный
     *****************************
     * .KEY V77708012            *
     * .COD 77708012 VEC         *
     * .MET 1                    *
     * 2                         *
     * 56.314014573 42.911885365 *
     * 56.962916333 44.038253903 *
     * .SEM 2                    *
     * 5400 10 дшд               *
     * 9216 КП                   *
     *****************************
    **/

    /// инициализируем модель картографических данных
    TXFDataWorker *txfDataWorker = new TXFDataWorker();
    /// ключ знака ( уникальный идентификатор )
    txfDataWorker->setKEY( "V77708012" );
    /// код знака ( код серии знаков )
    txfDataWorker->setCOD( "77708012" );
    /// тип знака ( векторный / линейный / площадной ) => VEC - векторный
    txfDataWorker->setCOD_TYPE( "VEC" );
    /// метрика знака
    /// координаты объекта ( 1я точка - расположение знака )
    txfDataWorker->setMETValue( "56.314014573", "42.911885365" );
    /// координаты объекта ( 2я точка - направление знака )
    txfDataWorker->setMETValue( "56.962916333", "44.038253903" );
    /// семантика знака
    /// надпись внутри знака
    txfDataWorker->setSEMValue( "5400", "10 дшд" );
    /// надпись возле знака
    txfDataWorker->setSEMValue( "9216", "КП" );
    /// добавляем модель картографических данных в коллекцию
    vfvpmodel.txfDataLst.append( txfDataWorker );
}

void MainWindow::onTreeViewItemClicked(const QModelIndex &modelIndex)
{

//        QString text;

//        // Заполняет выборочно
//        if (modelIndex.row() == 0)
//        {
////         textTab1Edit1->setText( modelIndex.data().toString() );
//         text = QString("Текст 1 вставка");
//         text =  modelIndex.data().toString();
//         textTab1Edit1->setText(text);
//        }
//        else if (modelIndex.row() == 1)
//        {
//            text = QString("Текст 2 вставка");
//        }
//        else if (modelIndex.row() == 2)
//        {
//            text = QString("Текст 3 вставка");
//            textTab3Edit3->setText(text);
//        }

        // выбор полей для заполнения
//        textTab1Edit1->setText(text);
//        textTab1Edit2->setText(text);
//        textTab2Edit3->setText(text);

//    // получаем текст элемента дерева
      //QMap<Int, QVariant> (QAbstractitemModel)
//    QString text = model->itemData(modelIndex).value(Qt::DisplayRole).toString();
//        // вставляем текст в соответствующее поле вкладки
//        if (text == "Текст 1")
//        {
//            textTab1Edit1->setText("Текст для Tab 1, TextEdit 1");
//        }
//        else if (text == "Текст 2")
//        {
//            textTab1Edit2->setText("Текст для Tab 1, TextEdit 2");
//        }
//        else if (text == "Вложенный текст")
//        {
//            textTab1Edit3->setText("Текст для Tab 1, TextEdit 3");
//        }
//        else if (text == "Вложенный текст")
//        {
//            textTab2Edit3->setText("Текст для Tab 2, TextEdit 3");
//        }
        // QList<QVariant> (QAbstractitemModel) с первого значения at(0)
//        QString text = model->itemData(modelIndex).values().at(0).toString();

//        // проверяю какая вкладка активна и устанавливаю текст
//        if (tabWidget->currentIndex() == 0)
//        {
//            textTab1Edit1->setText(text);
//        }
//        else if (tabWidget->currentIndex() == 1)
//        {
//            text = QString("Текст 3 вставка");
//            textTab1Edit3->setText(text);
//        }
//        QTextEdit *pTextEdit1 = centralWidget()->findChild < QTextEdit* > ( "TextEditTab1" );
//        QTextEdit *pTextEdit2 = centralWidget()->findChild < QTextEdit* > ( "qTextEdit2" );


//        qDebug() << __PRETTY_FUNCTION__ << pTextEdit1->objectName();
        // пример
        qDebug() << __PRETTY_FUNCTION__ << modelIndex.data(Qt::UserRole).toString();
//        qDebug() << __PRETTY_FUNCTION__ << pTextEdit2->objectName();

//        pTextEdit1->setText( modelIndex.data().toString());
//        pTextEdit2->setText( "TextEdit 2 new" );
//  textTab1Edit1->setText( modelIndex.data().toString() );
//  textTab1Edit2->setText( modelIndex.data().toString() );
//  textTab1Edit3->setText( modelIndex.data().toString() );
//  textTab2Edit3->setText( modelIndex.data().toString() );
        qDebug() << "Модель данных ТВФ в части ВФВП";

        /// характеристики ВФВП [ vfvp ]
        qDebug() << "характеристики ВФВП [ vfvp ]:";
        qDebug() << "vfvp_kod => " << vfvpmodel.charVfvp.vfvp_kod;
        qDebug() << "vfvp_org => " << vfvpmodel.charVfvp.vfvp_org;
        qDebug() << "vfvp_dt  => " << vfvpmodel.charVfvp.vfvp_dt;

        /// характеристики ВФВП [ vfvp ] => modelView
        textTab1Edit1->setText( vfvpmodel.charVfvp.vfvp_kod );
        textTab1Edit2->setText( vfvpmodel.charVfvp.vfvp_org );
        textTab1Edit3->setText( vfvpmodel.charVfvp.vfvp_dt.toString() );

        /// положение воинского формирования [ pvfvp ]
        qDebug() << "положение воинского формирования [ pvfvp ]:";
        qDebug() << "description => " << vfvpmodel.posVfvpLst.value( 0 ).description;
        qDebug() << "latitude    => " << vfvpmodel.posVfvpLst.value( 0 ).latitude;
        qDebug() << "longitude   => " << vfvpmodel.posVfvpLst.value( 0 ).longitude;
        qDebug() << "height      => " << vfvpmodel.posVfvpLst.value( 0 ).height;
        qDebug() << "OK          => " << vfvpmodel.posVfvpLst.value( 0 ).OK;

        /// положение воинского формирования [ pvfvp ] => modelView


        /// личный состав [ lsvfvp ]
        qDebug() << "личный состав [ lsvfvp ]:";
        qDebug() << "description => " << vfvpmodel.lsVfvpLst.value( 0 ).description;
        qDebug() << "kolshtat    => " << vfvpmodel.lsVfvpLst.value( 0 ).kolshtat;
        qDebug() << "kolnal      => " << vfvpmodel.lsVfvpLst.value( 0 ).kolnal;
        qDebug() << "ukompl      => " << vfvpmodel.lsVfvpLst.value( 0 ).ukompl;

        /// ВВТ [ vvtvfvp ]
        qDebug() << "ВВТ [ vvtvfvp ]:";
        qDebug() << "description => " << vfvpmodel.vvtVfsvLst.value( 0 ).description;
        qDebug() << "kkoovt_kod  => " << vfvpmodel.vvtVfsvLst.value( 0 ).kkoovt_kod;
        qDebug() << "kolshtat    => " << vfvpmodel.vvtVfsvLst.value( 0 ).kolshtat;
        qDebug() << "kolnal      => " << vfvpmodel.vvtVfsvLst.value( 0 ).kolnal;
        qDebug() << "ukompl      => " << vfvpmodel.vvtVfsvLst.value( 0 ).ukompl;

        /// картографические данные [ kdou ]
        qDebug() << "картографические данные [ kdou ]:";
        qDebug() << "KEY      => " << vfvpmodel.txfDataLst.value( 0 )->getKEY();
        qDebug() << "COD      => " << vfvpmodel.txfDataLst.value( 0 )->getCOD();
        qDebug() << "COD_TYPE => " << vfvpmodel.txfDataLst.value( 0 )->getCOD_TYPE();
        qDebug() << "MET 1    => " << vfvpmodel.txfDataLst.value( 0 )->getMET().first();
        qDebug() << "MET 2    => " << vfvpmodel.txfDataLst.value( 0 )->getMET().at( 1 );
        QString semKey( vfvpmodel.txfDataLst.value( 0 )->getSEMList().first() );
        qDebug() << "SEM 1    => " << semKey << vfvpmodel.txfDataLst.value( 0 )->getSEMValue( semKey );
        semKey = vfvpmodel.txfDataLst.value( 0 )->getSEMList().at( 1 );
        qDebug() << "SEM 2    => " << semKey << vfvpmodel.txfDataLst.value( 0 )->getSEMValue( semKey );

        /// картографические данные [ kdou ] ( txf )
        qDebug() << "картографические данные [ kdou ] ( txf ):";
        qDebug() << vfvpmodel.txfDataLst.at( 0 )->createTxfData().toStdString().c_str();

}
