#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTreeView>
#include <QStandardItemModel>
#include <QTabWidget>
#include <QLineEdit>
#include <QTextEdit>
#include <QWidget>
#include <QScrollArea>
#include <QtWidgets/QScrollBar>
#include "vfvpmodel/include/vfvpmodel.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    void createTreeView();
    void createTabWidget();

    /**
     * @brief setModel задаем модель данных
     * @param vfvpmodel модель данных
     */
    void setModel( VFVPModel &vfvpmodel );

private slots:
   void onTreeViewItemClicked(const QModelIndex &modelIndex);

private:
//    QVariantMap *itemData;
    QTreeView *treeView;
       QScrollArea *scrollArea;
    QStandardItemModel *model;
    QTabWidget *tabWidget;
    QWidget *tab1, *tab2, *tab3, *tab4, *tab5;
    QTextEdit *textTab1Edit1, *textTab1Edit2, *textTab1Edit3, *textTab1Edit4, *textTab1Edit5, *textTab1Edit6;
    QTextEdit *textTab1Edit7, *textTab1Edit8, *textTab1Edit9, *textTab1Edit10, *textTab1Edit11, *textTab1Edit12;
    QTextEdit *textTab1Edit13, *textTab1Edit14, *textTab1Edit15, *textTab1Edit16, *textTab1Edit17, *textTab1Edit18;
    QTextEdit *textTab1Edit19, *textTab1Edit20, *textTab1Edit21, *textTab1Edit22, *textTab1Edit23, *textTab1Edit24;
    QTextEdit *textTab1Edit25, *textTab1Edit26, *textTab1Edit27, *textTab1Edit28, *textTab1Edit29;
    QTextEdit *textTab2Edit1, *textTab2Edit2, *textTab2Edit3;
    QTextEdit *textTab3Edit1, *textTab3Edit2, *textTab3Edit3;
    QTextEdit *textTab4Edit1, *textTab4Edit2, *textTab4Edit3;
    QTextEdit *textTab5Edit1, *textTab5Edit2, *textTab5Edit3;
 QScrollBar *verticalScrollBar;
    VFVPModel vfvpmodel;
};

#endif // MAINWINDOW_H
