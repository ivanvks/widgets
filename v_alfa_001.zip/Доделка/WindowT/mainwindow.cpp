#include<QVBoxLayout>
#include <QDialog>
#include <QFile>
#include <QLabel>
#include <QFormLayout>

#include "mainwindow.h"
#include "configwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    tabWidget = new QTabWidget(this);

    QWidget *tab1 = new QWidget();
    tabWidget->addTab(tab1, "Tab 1");

    QWidget *tab2 = new QWidget();
    tabWidget->addTab(tab2, "Tab 2");

    QWidget *tab3 = new QWidget();
    tabWidget->addTab(tab3, "Tab 3");
/////////////////////////////////////////////////////////////////
    button = new QPushButton(this);
    button->setToolTip("Настройка сети");
  // button->setFixedSize(70, 70);
   // button->setStyleSheet(" { border-radius: 100px; }");
  button->setIcon(QIcon(":/images/images/blue.png")); // Устанавливаем изображение иконки
   // button->setIcon(QIcon(":/blue"));
   button->setIconSize(QSize(40, 40));
  // button->setFixedSize(28, 28);
  // button->setStyleSheet("QPushButton { border: none;}");
  //  button->setStyleSheet(" { border: none;}");
  //  button->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

   // QPushButton *button = new QPushButton("Open Window", this);
    int buttonSize = 40;  // Размер кнопки
    button->setFixedSize(buttonSize, buttonSize);
    int borderRadius = buttonSize / 2;  // Радиус скругления
  // button->setStyleSheet(QString("{ border-radius: %1px; }").arg(borderRadius));
    button->setStyleSheet(QString("QPushButton { border-radius: %1px; }").arg(borderRadius));


    connect(button, &QPushButton::clicked, this, &MainWindow::openNewWindow);

    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);
    layout->addWidget(button, 0, Qt::AlignTop | Qt::AlignRight);
   // layout->addWidget(button, 0, 4);

    layout->addWidget(tabWidget);

    setCentralWidget(centralWidget);
}

void MainWindow::openNewWindow()
{
    ConfigWindow *configWindow = new ConfigWindow(this);
    configWindow->exec();
}
