/** **************************************
 *  Author:  Koshurnikov A.A.            *
 *  E-mail:  koshurnikovaa@niissu.ru     *
 *  Date:    2020-11-17                  *
 *  Summary: ПОвз Кассиопея-Д и Орлан-10 *
 *  License: NIISSU                      *
 ****************************************/

/**
 * ISKAO    - Interaction Software Kassiopeya-D And Orlan-10
 * Орлан-10 - Наземный пунт управления БЛА
 */

#ifndef ISKAO_H
#define ISKAO_H

#include "csettings.h"
#include "csqldatabase.h"
#include "cnetworkaccessmanager.h"

#include <QObject>
#include <QTimer>

class Iskao : public QObject
{
    Q_OBJECT

    /// объект таймера проверки сообщений
    QTimer                *tmrCheck;
    /// объект подключение к базе данных
    CSqlDatabase          *asuvDataBase_;
    /// объект для работы с web service
    CNetworkAccessManager *webManager_;
    /// контейнер сообщений
    QVector < QByteArray > dataMSG_;
    /// объект конфигурации
    CSettings             *cSettings_;

public:
    Iskao( QObject *parent = nullptr );
    /**
     * @brief run - Запуск работы класса взаимодействия
     */
    void run();

private slots:
    /**
     * @brief checkMsg - Слот проверки новых сообщений
     */
    void checkMsg();
    /**
     * @brief exit - Слот завершения работы программы
     */
    void exit();
    /**
     * @brief checkSocket - Проверка на online web service
     * @return            - [true] -> online
     */
    bool checkSocket();
    /**
     * @brief runInteraction - Запуск взаимодействия
     * @param access         - [true] -> аутентификация прошла успешно
     */
    void runInteraction( bool access );
};

#endif // ISKAO_H
