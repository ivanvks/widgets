#ifndef CSETTINGS_H
#define CSETTINGS_H

#include <QSettings>
#include <QObject>

class CSettings : public QSettings
{
    Q_OBJECT

    /// Параметры базы данных для взаимодействия с ASUV
    QStringList asuvParam_;
    /// параметры для взаимодействия с web service
    QStringList webParam_;
    /// Параметры периодичности опроса базы данных ASUV
    int         msec_;

public:
    CSettings();
    /**
     * @brief checkConfigFile - Проверка файла конфигурации
     * @return                - [true] -> файл конфигурации найден
     */
    bool checkConfigFile();
    /**
     * @brief asuvParam - Возвращаем параметры базы данных для взаимодействия с ASUV
     * @return          - параметры базы данных для взаимодействия с ASUV
     */
    QStringList asuvParam() const;
    /**
     * @brief webParam - Возвращаем параметры для взаимодействия с web service
     * @return         - параметры для взаимодействия с web service
     */
    QStringList webParam() const;
    /**
     * @brief msec - Возвращаем параметры периодичности опроса базы данных ASUV
     * @return     - параметры периодичности опроса базы данных ASUV
     */
    int msec() const;

private:
    /**
     * @brief loadSettings - Загрузка файла конфигурации
     * @return             - результат проверки наличия файла конфигурации
     */
    bool loadSettings();
    /**
     * @brief createSettingsFile - Создание файла конфигурации
     */
    void createSettingsFile();
    /**
     * @brief settingDebug - Выводим в консоль текущую конфигурацию
     */
    void settingDebug();
};

#endif // CSETTINGS_H
