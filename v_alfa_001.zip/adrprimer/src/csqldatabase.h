#ifndef CSQLDATABASE_H
#define CSQLDATABASE_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QObject>

class CSqlDatabase : public QObject
{
    Q_OBJECT

    /// объект подключения к базе данных
    QSqlDatabase    sqlDataBase_;

public:
    CSqlDatabase( const QString &driver );
    /**
     * @brief openDataBase - Инициируем подключение к базе данных
     * @param paramLst     - параметры подключения к базе данных
     * @return             - статус подключения к базе данных
     */
    bool openDataBase( const QStringList paramLst );
    /**
     * @brief selectFromInMSGIS - Получение данных из БД
     * @return                  - вектор данных из БД
     */
    QVector < QByteArray > selectFromInMSGIS();

private:
    /**
     * @brief deleteFromInMSGIS - Удаление обработанных сообщений
     * @param idLst             - список id обработанных сообщений
     */
    void deleteFromInMSGIS( const QStringList &idLst );
};

#endif // CSQLDATABASE_H
