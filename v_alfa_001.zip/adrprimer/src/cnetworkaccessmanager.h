#ifndef CNETWORKACCESSMANAGER_H
#define CNETWORKACCESSMANAGER_H

#include <QNetworkAccessManager>
#include <QHttpPart>
#include <QNetworkReply>
#include <QObject>
#include <QAuthenticator>
#include <QSharedPointer>

class CNetworkAccessManager : public QNetworkAccessManager
{
    Q_OBJECT

    /// Тело post запроса
    QHttpMultiPart *multiPart_;
    /// Объект ответа web service на post запрос
    QNetworkReply  *reply_;

    /// Хост web service
    QString host_;
    /// Порт web service
    QString port_;
    /// Имя пользователя web service
    QString user_;
    /// Пароль пользователя web service
    QString pass_;
    /// флаг первой аутентификации
    bool firstAuthentication = true;

public:
    CNetworkAccessManager( const QStringList &params );

    /**
     * @brief setParams - Задаем параметры для взаимодействия с web service
     * @param params    - параметры для взаимодействия с web service
     */
    void setParams( const QStringList &params );

    /**
     * @brief sendMessage - Отправка сообщения на web service
     * @param value       - контент для web service
     */
    void sendMessage( const QByteArray &data );

    /**
     * @brief checkNetworkAccess - Проверка аутентификации пользователя
     */
    void checkNetworkAccess();

private slots:

    /**
     * @brief getResponse - Получаем ответ от web service
     * @param reply       - ответ от web service
     */
    void getResponse( QNetworkReply* reply);

    /**
     * @brief authenticationRequired - Проводим аутентификацию пользователя
     * @param reply                  - post запрос
     * @param auth                   - данные аутентификации
     */
    void authenticationRequired( QNetworkReply *reply, QAuthenticator *auth );

signals:
    /**
     * @brief webServiceAccess - результат аутентификации пользователя
     * [true]   -> аутентификация пройдена успешно
     * [false]  -> аутентификация не пройдена
     */
    void webServiceAccess( bool );
};

#endif // CNETWORKACCESSMANAGER_H
