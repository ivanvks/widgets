#include "csettings.h"

#include <QFile>
#include <QDir>
#include <QDebug>

CSettings::CSettings() {}

/// Проверка файла конфигурации
bool CSettings::checkConfigFile()
{
    /// проверка наличи файла конфигурации
    qDebug() << "\n"; qDebug() << "[CHECK CONFIG FILE]";
    if ( !loadSettings() ) {
        /// создание файла конфигурации
        createSettingsFile();
        return false;
    } else {
        /// выводим в консоль текущую конфигурацию
        settingDebug();
        qDebug() << "=> Please check" << QString( fileName() );
        return true;
    }
}

/// Загрузка файла конфигурации
bool CSettings::loadSettings()
{
    /// Задаем файл конфигурации
    QSettings settings( "iskao.conf", QSettings::IniFormat );

    /// Задаем параметры базы данных для взаимодействия с ASUV
    settings.beginGroup( "DataBase" );

    /// Задаем хост базы данных
    asuvParam_.append( settings.value( "host", "localhost" ).toString() );

    /// Задаем порт базы данных
    asuvParam_.append( settings.value( "port", "5432" ).toString() );

    /// Задаем имя базы данных
    asuvParam_.append( settings.value( "name", "asuv" ).toString() );

    /// Задаем имя пользователя
    asuvParam_.append( settings.value( "user", "asuv" ).toString() );

    /// Задаем пароль пользователя
    asuvParam_.append( settings.value( "pass", "" ).toString() );

    settings.endGroup();

    /// Задаем параметры для взаимодействия с web service
    settings.beginGroup( "WebService" );

    /// Задаем хост web service
    webParam_.append( settings.value( "host", "localhost" ).toString() );

    /// Задаем порт web service
    webParam_.append( settings.value( "port", "80" ).toString() );

    /// Задаем имя пользователя web service
    webParam_.append( settings.value( "user", "kassiopeya-d" ).toString() );

    /// Задаем пароль пользователя web service
    webParam_.append( settings.value( "pass", "kassiopeya-d" ).toString() );

    settings.endGroup();

    /// Задаем параметры периодичности опроса базы данных ASUV
    settings.beginGroup( "Timer" );

    /// Задаем периодичность опроса базы данных ASUV
    msec_ = settings.value( "msec", "5000" ).toInt();

    settings.endGroup();

    /// Создаем пример файла конфигурации
    return QFile( "iskao.conf" ).open( QIODevice::ReadOnly );
}

/// Создание файла конфигурации
void CSettings::createSettingsFile()
{
    /// Задаем файл конфигурации
    QSettings settings( "iskao.conf", QSettings::IniFormat );

    /// Задаем параметры базы данных для взаимодействия с ASUV
    settings.beginGroup( "DataBase" );

    /// Задаем хост базы данных
    settings.setValue( "host", "localhost" );
    /// Задаем порт базы данных
    settings.setValue( "port", "5432" );
    /// Задаем имя базы данных
    settings.setValue( "name", "asuv" );
    /// Задаем имя пользователя
    settings.setValue( "user", "asuv" );
    /// Задаем пароль пользователя
    settings.setValue( "pass", "" );

    settings.endGroup();

    /// Задаем параметры для взаимодействия с web service
    settings.beginGroup( "WebService" );

    /// Задаем хост web service
    settings.setValue( "host", "localhost" );
    /// Задаем порт web service
    settings.setValue( "port", "8080" );
    /// Задаем имя пользователя web service
    settings.setValue( "user", "kassiopeya-d" );
    /// Задаем пароль пользователя web service
    settings.setValue( "pass", "kassiopeya-d" );

    settings.endGroup();

    /// Задаем параметры периодичности опроса базы данных ASUV
    settings.beginGroup( "Timer" );

    /// Задаем периодичность опроса базы данных ASUV
    settings.setValue( "msec", "5000" );

    settings.endGroup();

    /// выводим информацию для пользователя
    qDebug() << "=> iskao.conf not found";
    qDebug() << "=> Generate new config file...";
    qDebug() << "=> Please check" << QString( fileName() );
}

/// Выводим в консоль текущую конфигурацию
void CSettings::settingDebug()
{
    qDebug() << "=> OK";
    qDebug() << "\n"; qDebug() << "[SETTINGS]";
    qDebug() << "Timer:" << msec_ << "msec";
    qDebug() << "DataBase:" << asuvParam_;
    qDebug() << "WebService:" << webParam_;
}

/// Возвращаем параметры базы данных для взаимодействия с ASUV
QStringList CSettings::asuvParam() const
{
    return asuvParam_;
}

/// Возвращаем параметры для взаимодействия с web service
QStringList CSettings::webParam() const
{
    return webParam_;
}

/// Возвращаем параметры периодичности опроса базы данных ASUV
int CSettings::msec() const
{
    return msec_;
}
