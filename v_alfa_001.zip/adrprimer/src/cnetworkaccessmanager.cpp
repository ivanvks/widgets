#include "cnetworkaccessmanager.h"

CNetworkAccessManager::CNetworkAccessManager( const QStringList &params )
{
    /// соединяем сигнал/слот обработки аутентификации
    connect(this,SIGNAL(authenticationRequired(QNetworkReply*,QAuthenticator*)),
            SLOT(authenticationRequired(QNetworkReply*,QAuthenticator*)));
    /// соединяем сигнал/слот обработки post запроса
    connect(this,SIGNAL(finished(QNetworkReply*)),SLOT(getResponse(QNetworkReply*)));

    /// Задаем параметры для взаимодействия с web service
    setParams( params );
}

/// Получаем ответ от web service
void CNetworkAccessManager::getResponse(QNetworkReply *reply)
{
    /// аутентификация пройдена успешно
    qDebug() << __PRETTY_FUNCTION__ << "[ACCESS ACCEPTED]";
    emit webServiceAccess( true );
    /// выводим результат запроса в концоль
    qDebug() << "\n"; qDebug() << __PRETTY_FUNCTION__ << "[HEADER] =>" << reply->rawHeaderPairs();
    qDebug() << __PRETTY_FUNCTION__             << "[BODY] =>"   << reply->readAll();
}

/// Проводим аутентификацию пользователя
void CNetworkAccessManager::authenticationRequired( QNetworkReply *reply, QAuthenticator *auth )
{
    /// проверка на зацикливание аутентификации ( incorrect login/pass )
    if ( firstAuthentication ) {
        qDebug() << "\n"; qDebug() << __PRETTY_FUNCTION__
                 << "[CHECK WEB SERVICE ACCESS] =>" << reply->url().toString();
        firstAuthentication = false;
    } else {
        /// аутентификация не пройдена
        qDebug() << __PRETTY_FUNCTION__ << "[ACCESS DENIED]";
        emit webServiceAccess( false );
    }
    /// передаем параметры для аутентификации
    auth->setUser    ( user_ );
    auth->setPassword( pass_ );
}

void CNetworkAccessManager::checkNetworkAccess()
{
    ///  задаем полный адрес отправки сообщения ( http://10.58.1.30:8080/irz/andr/test )
    QString request( "http://" );
            request.append( host_ ).append( ":" ).append( port_ ).append( "/irz/andr/test" );

    /// отправляем сообщение на web service посредством get запроса
    get( QNetworkRequest( QUrl( request ) ) );
}

/// Задаем параметры для взаимодействия с web service
void CNetworkAccessManager::setParams( const QStringList &params )
{

    /// Задаем хост web service
    host_ = params.at( 0 );
    /// Задаем порт web service
    port_ = params.at( 1 );
    /// Задаем имя пользователя web service
    user_ = params.at( 2 );
    /// Задаем пароль пользователя web service
    pass_ = params.at( 3 );
}

/// Отправка сообщения на web service
void CNetworkAccessManager::sendMessage( const QByteArray &data )
{
    /// создаем новое тело post запроса
    multiPart_ = new QHttpMultiPart( QHttpMultiPart::FormDataType );
    /// задаем тип тередаваемого контента ( обычный текст )
    QHttpPart httpPart;
    httpPart.setHeader( QNetworkRequest::ContentTypeHeader, QVariant( "text/plain" ) );
    /// задаем наименование контейнера с данными
    httpPart.setHeader( QNetworkRequest::ContentDispositionHeader,
                        QVariant( "form-data; name=\"vfsv\"" ) );

    ///  задаем полный адрес отправки сообщения ( http://10.58.1.30:8080/irz/andr/post )
    QString request( "http://" );
            request.append( host_ ).append( ":" ).append( port_ ).append( "/irz/andr/post" );

    /// задаем контент для web service
    httpPart.setBody( data );
    /// добавляем в тело post запроса шапку и контент
    multiPart_->append( httpPart );

    /// отправляем сообщение на web service посредством post запроса
    reply_ = post( QNetworkRequest( QUrl( request ) ), multiPart_ );
    /// задаем родителя телу post запроса для очитски памяти
    multiPart_->setParent( reply_ );
}
