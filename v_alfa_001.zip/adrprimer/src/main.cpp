#include "iskao.h"

#include <QCoreApplication>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    Iskao isaak( &a );
    isaak.run();

    return a.exec();
}
