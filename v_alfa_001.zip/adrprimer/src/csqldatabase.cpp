#include "csqldatabase.h"

#include <QDebug>

CSqlDatabase::CSqlDatabase( const QString &driver )
{
    /// инициализируем объект для работы с базой данных
    sqlDataBase_ = QSqlDatabase::addDatabase( driver );
}

/// Инициируем подключение к базе данных
bool CSqlDatabase::openDataBase(const QStringList paramLst)
{
    /// Задаем хост базы данных
    sqlDataBase_.setHostName( paramLst.at( 0 ) );
    /// Задаем порт базы данных
    sqlDataBase_.setPort( paramLst.at( 1 ).toInt() );
    /// Задаем имя базы данных
    sqlDataBase_.setDatabaseName( paramLst.at( 2 ) );
    /// Задаем имя пользователя
    sqlDataBase_.setUserName( paramLst.at( 3 ) );
    /// Задаем пароль пользователя
    sqlDataBase_.setPassword( paramLst.at( 4 ) );
    /// Подключение к базе данных
    qDebug() << "\n"; qDebug() <<  __PRETTY_FUNCTION__ << "[CHECK DATABASE ACCESS] =>"
             << QString( "%1:%2" ).arg( sqlDataBase_.hostName() ).arg( sqlDataBase_.port() );
    if ( !sqlDataBase_.open() ) {
        qDebug() << __PRETTY_FUNCTION__ << "[ACCESS DENIED]";
        qDebug() << __PRETTY_FUNCTION__ << sqlDataBase_.lastError();
        return false;
    } else {
        qDebug() << __PRETTY_FUNCTION__ << "[ACCESS ACCEPTED]";
        return true;
    }
}

/// Получение данных из БД
QVector < QByteArray > CSqlDatabase::selectFromInMSGIS()
{
    /// создаем пустой вектор данных
    QVector < QByteArray >  dataVector;
    /// инициализируем запрос к базе данных
    QSqlQuery sqlQuery( sqlDataBase_.database( "default" ) );
    if( !sqlQuery.exec( "SELECT msg_id,msg_data FROM "
                     "is_msg "
                     "WHERE msg_type = '26' "
                     "AND msg_subtype = '514949' "
                     "LIMIT 1" ) ) {
        qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
        /// возвращаем пустой вектор данных
        return dataVector;
    }

    /// получаем сообщения
    QStringList idLst;
    while ( sqlQuery.next() ) {
        /// запоняем пустой вектор данных
        dataVector.append( sqlQuery.value( 1 ).toByteArray() );
        /// запоминаем обработанные сообщения
        idLst.append( sqlQuery.value( 0 ).toString() );
    }
    /// удаляем обработанные сообщений
    deleteFromInMSGIS( idLst );

    /// возвращаем вектор данных
    return dataVector;
}

/// Удаление обработанных сообщений
void CSqlDatabase::deleteFromInMSGIS(const QStringList &idLst)
{
    /// проверка на пустой список сообщений на удаление
    if ( idLst.isEmpty() ) return;

    QSqlQuery sqlQuery( sqlDataBase_.database( "default" ) );
    /// удаление обработанных сообщений
    if ( !sqlQuery.exec( QString( "DELETE FROM is_msg WHERE msg_id IN (%1)" )
                     .arg( idLst.join( "," ) ) ) )
         qDebug() << __PRETTY_FUNCTION__ << sqlQuery.lastQuery() << sqlQuery.lastError();
}
