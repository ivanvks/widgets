#include "iskao.h"

#include <QDebug>
#include <QUdpSocket>

Iskao::Iskao( QObject *parent ) : QObject( parent )
{
    /// запуск с приветствием
    qDebug() << "\n"; qDebug () << "ISKAO - Interaction Software Kassiopeya-D And Orlan-10";
    /// считываем конфиг файл ( isaak.conf )
    cSettings_ = new CSettings();
    /// создаем подключение к базе данных
//    asuvDataBase_ = new CSqlDatabase( "QPSQL" );
}

void Iskao::run()
{
    /// Проверка файла конфигурации
    if ( !cSettings_->checkConfigFile() ) { exit(); return; }
    /// проверка на подключение к базе данных
    if ( !asuvDataBase_->openDataBase( cSettings_->asuvParam() ) ) { exit(); return; }
    /// Проверка на online web service
    if ( !checkSocket() ) { exit(); return; }

    /// создаем post запрос и передаем в него данные для шапки
    webManager_ = new CNetworkAccessManager( cSettings_->webParam() );
    /// соединяем сигнал/слот запуска взаимодействия
    connect( webManager_, SIGNAL( webServiceAccess( bool ) ), SLOT( runInteraction( bool ) ) );
    /// проверка связи с Web Servise
    webManager_->checkNetworkAccess();

    /// создаем таймер проверки сообщений
    tmrCheck = new QTimer();
    /// соединяем сигнал/слот проверки сообщений по таймеру
    connect( tmrCheck, SIGNAL( timeout() ), this, SLOT( checkMsg() ) );
}

void Iskao::checkMsg()
{
    /// получаем данные из БД
//    dataMSG_ = asuvDataBase_->selectFromInMSGIS();
//    qDebug() << __PRETTY_FUNCTION__ << "[TVF MSG] =>" << dataMSG_.count();
    /// Проверка на пустой контейнер сообщений
//    if ( dataMSG_.isEmpty() ) return;
    /// инициализируем парсер протокола ТВФ
//    VfsvParser  tvfParser( dataMSG_.first() );
    /// отправляем сообщение на web service
//    webManager_->sendMessage( tvfParser.getXmlData() );
    webManager_->sendMessage( "Hello Orlan-10" );
}

/// Слот завершения работы программы
void Iskao::exit()
{
    /// сигнал завершения работы программы
    QTimer::singleShot( 500, parent(), SLOT( quit() ) );
}

/// Проверка на online web service
bool Iskao::checkSocket()
{
    /// создаем сокет для подключения в web service
    QTcpSocket webSocket;
    webSocket.connectToHost( cSettings_->webParam().at( 0 ),
                             cSettings_->webParam().at( 1 ).toInt() );
    qDebug() << "\n"; qDebug() << __PRETTY_FUNCTION__ << "[CHECK WEB SERVICE SOCKET] =>"
             << QString( "%1:%2" ).arg( cSettings_->webParam().at( 0 ) )
                .arg( cSettings_->webParam().at( 1 ) );
    /// ждем отклика от web service 3000 мсек
    if( webSocket.waitForConnected( 3000 ) ) {
        /// [web service] -> online
        qDebug() << __PRETTY_FUNCTION__ << "[SOCKET ONLINE]";
        /// отключаемся от web service
        webSocket.disconnectFromHost();
        return true;
    }
    /// [web service] -> offline
    qDebug() << __PRETTY_FUNCTION__ << "[NO ROUTE TO HOST OR SOCKET OFFLINE]";
    return false;
}

/// Запуск взаимодействия
void Iskao::runInteraction( bool access )
{
    /// проверяем успешность прохождения аутентификации
    ( access ) ?
    /// запускаем таймер проверки сообщений ( мсек )
    tmrCheck->start( cSettings_->msec() ) :
    /// завершаем работу программы
    exit()                                ;
}
