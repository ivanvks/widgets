#include "mainwindow.h"

#include <QMenuBar>
#include <QMenu>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QStandardItem>
#include <QLabel>
#include <QString>
#include <QVariantMap>
#include <QDebug>
//#include <QAbstractScrollArea>


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    createTreeView();
    createTabWidget();

    // добавляю горизонтальный разделитель
    QSplitter *splitter = new QSplitter(Qt::Horizontal, this);
    splitter->addWidget(treeView);
    splitter->addWidget(tabWidget);
    splitter->setStretchFactor(1, 1);
    splitter->setCollapsible(0, false);
    splitter->setCollapsible(1, false);

    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);
    layout->addWidget(splitter);
    setCentralWidget(centralWidget);

    // подключаем слот к сигналу clicked дерева
//   connect(treeView, &QTreeView::clicked, this, &MainWindow::onTreeViewItemClicked);
    connect( treeView, SIGNAL( clicked(QModelIndex)),
            this, SLOT( onTreeViewItemClicked(QModelIndex))
             );

    setModel( vfvpmodel );
    this->setWindowTitle("Lesson_5");

}

MainWindow::~MainWindow()
{
}


void MainWindow::createTreeView()
{
    // добавляю дерево списков
    model = new QStandardItemModel(this);
    QStandardItem *rootItem = model->invisibleRootItem();

    QStandardItem *item1 = new QStandardItem("Текст 1");
    // пример
    item1->setData( "item1", Qt::UserRole );
    rootItem->appendRow(item1);

    QStandardItem *item1_1 = new QStandardItem("Вложенный текст");
    item1->appendRow(item1_1);
    /// вложение во вложение в Текст 1 если нужно
//    QStandardItem *item3 = new QStandardItem(tr("Перевложенный текст"));
//    item1->appendRow(item3);
    QStandardItem *item2 = new QStandardItem("Текст 2");
    rootItem->appendRow(item2);
    QStandardItem *item3 = new QStandardItem("Текст 3");
    rootItem->appendRow(item3);

    treeView = new QTreeView(this);
    treeView->setModel(model);
    treeView->setHeaderHidden(true);
    treeView->setSelectionMode(QAbstractItemView::SingleSelection);
}

void MainWindow::createTabWidget()
{
    // добавляю вкладки
    tabWidget = new QTabWidget(this);

//    // добавляем вертикальную прокрутку к виджету вкладок
//       scrollArea = new QScrollArea(tabWidget);
//       scrollArea->setWidgetResizable(true);
//       scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//       scrollArea->setFrameShape(QFrame::NoFrame);
//       scrollArea->setWidget(tabWidget);

    tab1 = new QWidget(tabWidget);
//    tab1->setObjectName(QString::fromUtf8("tab1"));
//    verticalScrollBar = new QScrollBar(tab1);
//    verticalScrollBar->setObjectName(QString::fromUtf8("verticalScrollBar"));
//    verticalScrollBar->setGeometry(QRect(600, 0, 16, 541));
//    verticalScrollBar->setOrientation(Qt::Vertical);
    tab2 = new QWidget(tabWidget);
    tab3 = new QWidget(tabWidget);
    tab4 = new QWidget(tabWidget);
    tab5 = new QWidget(tabWidget);
    tab6 = new QWidget(tabWidget);

    tabWidget->addTab(tab1, ("tab1"));
    tabWidget->addTab(tab2, ("tab2"));
    tabWidget->addTab(tab3, ("tab3"));
    tabWidget->addTab(tab4, ("tab4"));
    tabWidget->addTab(tab5, ("tab5"));
    tabWidget->addTab(tab6, ("tab6"));

    // добавляю QScrollArea для вертикального скроллинга
        QScrollArea* scrollArea = new QScrollArea(tab1);
        scrollArea->setWidgetResizable(true);
        scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        tab1->setLayout(new QVBoxLayout(tab1));
        tab1->layout()->addWidget(scrollArea);

        // добавл текстовые поля в QScrollArea
//            QWidget* scrollWidget = new QWidget(scrollArea);
//            scrollWidget->setLayout(new QVBoxLayout(scrollWidget));
//            scrollArea->setWidget(scrollWidget);

            QWidget *scrollWidget = new QWidget(scrollArea);
            scrollArea->setWidget(scrollWidget);

            QVBoxLayout *scrollLayout = new QVBoxLayout(scrollWidget);
            scrollWidget->setLayout(scrollLayout);

            textTab1Edit1 = new QTextEdit(scrollWidget);
            textTab1Edit1->setObjectName("TextEdit1Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit1);
            textTab1Edit2 = new QTextEdit(scrollWidget);
            textTab1Edit2->setObjectName("TextEdit2Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit2);
            textTab1Edit3 = new QTextEdit(scrollWidget);
            textTab1Edit3->setObjectName("TextEdit3Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit3);
            textTab1Edit4 = new QTextEdit(scrollWidget);
            textTab1Edit4->setObjectName("TextEdit4Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit4);
            textTab1Edit5 = new QTextEdit(scrollWidget);
            textTab1Edit5->setObjectName("TextEdit5Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit5);
            textTab1Edit6 = new QTextEdit(scrollWidget);
            textTab1Edit6->setObjectName("TextEdit6Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit6);
            textTab1Edit7 = new QTextEdit(scrollWidget);
            textTab1Edit7->setObjectName("TextEdit7Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit7);
            textTab1Edit8 = new QTextEdit(scrollWidget);
            textTab1Edit8->setObjectName("TextEdit8Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit8);
            textTab1Edit9 = new QTextEdit(scrollWidget);
            textTab1Edit9->setObjectName("TextEdit9Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit9);
            textTab1Edit10 = new QTextEdit(scrollWidget);
            textTab1Edit10->setObjectName("TextEdit10Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit10);
            textTab1Edit11 = new QTextEdit(scrollWidget);
            textTab1Edit11->setObjectName("TextEdit11Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit11);
            textTab1Edit12 = new QTextEdit(scrollWidget);
            textTab1Edit12->setObjectName("TextEdit12Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit12);

            textTab1Edit13 = new QTextEdit(scrollWidget);
            textTab1Edit13->setObjectName("TextEdit13Tab1");
            scrollWidget->layout()->addWidget(textTab1Edit13);
            textTab1Edit14 = new QTextEdit(scrollWidget);
            textTab1Edit14->setObjectName("TextEdit14Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit14);
            textTab1Edit15 = new QTextEdit(scrollWidget);
            textTab1Edit15->setObjectName("TextEdit15Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit15);
            textTab1Edit16 = new QTextEdit(scrollWidget);
            textTab1Edit16->setObjectName("TextEdit16Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit16);
            textTab1Edit17 = new QTextEdit(scrollWidget);
            textTab1Edit17->setObjectName("TextEdit17Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit17);
            textTab1Edit18 = new QTextEdit(scrollWidget);
            textTab1Edit18->setObjectName("TextEdit18Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit18);
            textTab1Edit19 = new QTextEdit(scrollWidget);
            textTab1Edit19->setObjectName("TextEdit19Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit19);
            textTab1Edit20 = new QTextEdit(scrollWidget);
            textTab1Edit20->setObjectName("TextEdit20Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit20);
            textTab1Edit21 = new QTextEdit(scrollWidget);
            textTab1Edit21->setObjectName("TextEdit21Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit21);
            textTab1Edit22 = new QTextEdit(scrollWidget);
            textTab1Edit22->setObjectName("TextEdit22Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit22);
            textTab1Edit23 = new QTextEdit(scrollWidget);
            textTab1Edit23->setObjectName("TextEdit23Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit23);
            textTab1Edit24 = new QTextEdit(scrollWidget);
            textTab1Edit24->setObjectName("TextEdit24Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit24);
            textTab1Edit25 = new QTextEdit(scrollWidget);
            textTab1Edit25->setObjectName("TextEdit25Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit25);
            textTab1Edit26 = new QTextEdit(scrollWidget);
            textTab1Edit26->setObjectName("TextEdit26Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit26);
            textTab1Edit27 = new QTextEdit(scrollWidget);
            textTab1Edit27->setObjectName("TextEdit27Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit27);
            textTab1Edit28 = new QTextEdit(scrollWidget);
            textTab1Edit28->setObjectName("TextEdit28Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit28);
            textTab1Edit29 = new QTextEdit(scrollWidget);
            textTab1Edit29->setObjectName("TextEdit29Tab1");
              scrollWidget->layout()->addWidget(textTab1Edit29);


//    QVBoxLayout *tab1Layout = new QVBoxLayout(tab1);
//   textTab1Edit1 = new QTextEdit(tab1);
//   textTab1Edit1->setObjectName("TextEdit1Tab1");
//  // textTab1Edit1->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit2 = new QTextEdit(tab1);
//   textTab1Edit2->setObjectName("TextEdit2Tab1");
//   //textTab1Edit2->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit3 = new QTextEdit(tab1);
//   textTab1Edit3->setObjectName("TextEdit3Tab1");
//   //textTab1Edit3->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit4 = new QTextEdit(tab1);
//   textTab1Edit4->setObjectName("TextEdit4Tab1");
//  // textTab1Edit4->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit5 = new QTextEdit(tab1);
//   textTab1Edit5->setObjectName("TextEdit5Tab1");
//  // textTab1Edit5->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit6 = new QTextEdit(tab1);
//   textTab1Edit6->setObjectName("TextEdit6Tab1");
//  // textTab1Edit6->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit7 = new QTextEdit(tab1);
//   textTab1Edit7->setObjectName("TextEdit7Tab1");
//   //textTab1Edit7->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit8 = new QTextEdit(tab1);
//   textTab1Edit8->setObjectName("TextEdit8Tab1");
//  // textTab1Edit8->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//   textTab1Edit9 = new QTextEdit(tab1);
//   textTab1Edit9->setObjectName("TextEdit9Tab1");
//   textTab1Edit10 = new QTextEdit(tab1);
//   textTab1Edit10->setObjectName("TextEdit10Tab1");
//   textTab1Edit11 = new QTextEdit(tab1);
//   textTab1Edit11->setObjectName("TextEdit11Tab1");
//   textTab1Edit12 = new QTextEdit(tab1);
//   textTab1Edit12->setObjectName("TextEdit12Tab1");

       //QTextEdit* pTeTab1 = new QTextEdit(tab1);
      // pTeTab1->setObjectName("TextEditTab1");

  //  tab1->setLayout( tab1Layout );

       // tab1->setLayout( scrollLayout );
  // tab1->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    // добавляю подписи лейблы
            QLabel *labela1Tab1 = new QLabel(("Текст 1:"), scrollWidget);
            scrollLayout->addWidget(labela1Tab1);
            scrollLayout->addWidget(textTab1Edit1);


            QLabel *labela2Tab1 = new QLabel(("Текст 2:"), scrollWidget);
            scrollLayout->addWidget(labela2Tab1);
            scrollLayout->addWidget(textTab1Edit2);

            QLabel *labela3Tab1 = new QLabel(("Текст 3:"), scrollWidget);
            scrollLayout->addWidget(labela3Tab1);
            scrollLayout->addWidget(textTab1Edit3);

            QLabel *labela4Tab1 = new QLabel(("Текст 4:"), scrollWidget);
            scrollLayout->addWidget(labela4Tab1);
            scrollLayout->addWidget(textTab1Edit4);

            QLabel *labela5Tab1 = new QLabel(("Текст 5:"), scrollWidget);
            scrollLayout->addWidget(labela5Tab1);
            scrollLayout->addWidget(textTab1Edit5);

            QLabel *labela6Tab1 = new QLabel(("Текст 6:"), scrollWidget);
            scrollLayout->addWidget(labela6Tab1);
            scrollLayout->addWidget(textTab1Edit6);

            QLabel *labela7Tab1 = new QLabel(("Текст 7:"), scrollWidget);
            scrollLayout->addWidget(labela7Tab1);
            scrollLayout->addWidget(textTab1Edit7);

            QLabel *labela8Tab1 = new QLabel(("Текст 8:"), scrollWidget);
            scrollLayout->addWidget(labela8Tab1);
            scrollLayout->addWidget(textTab1Edit8);

            QLabel *labela9Tab1 = new QLabel(("Текст 9:"), scrollWidget);
            scrollLayout->addWidget(labela9Tab1);
            scrollLayout->addWidget(textTab1Edit9);

            QLabel *labela10Tab1 = new QLabel(("Текст 10:"), scrollWidget);
            scrollLayout->addWidget(labela10Tab1);
            scrollLayout->addWidget(textTab1Edit10);

            QLabel *labela11Tab1 = new QLabel(("Текст 11:"), scrollWidget);
            scrollLayout->addWidget(labela11Tab1);
            scrollLayout->addWidget(textTab1Edit11);

            QLabel *labela12Tab1 = new QLabel(("Текст 12:"), scrollWidget);
            scrollLayout->addWidget(labela12Tab1);
            scrollLayout->addWidget(textTab1Edit12);

            QLabel *labela13Tab1 = new QLabel(("Текст 13:"), scrollWidget);
            scrollLayout->addWidget(labela13Tab1);
            scrollLayout->addWidget(textTab1Edit13);

            QLabel *labela14Tab1 = new QLabel(("Текст 14:"), scrollWidget);
            scrollLayout->addWidget(labela14Tab1);
            scrollLayout->addWidget(textTab1Edit14);

            QLabel *labela15Tab1 = new QLabel(("Текст 15:"), scrollWidget);
            scrollLayout->addWidget(labela15Tab1);
            scrollLayout->addWidget(textTab1Edit15);

            QLabel *labela16Tab1 = new QLabel(("Текст 16:"), scrollWidget);
            scrollLayout->addWidget(labela16Tab1);
            scrollLayout->addWidget(textTab1Edit16);

            QLabel *labela17Tab1 = new QLabel(("Текст 17:"), scrollWidget);
            scrollLayout->addWidget(labela17Tab1);
            scrollLayout->addWidget(textTab1Edit17);

            QLabel *labela18Tab1 = new QLabel(("Текст 18:"), scrollWidget);
            scrollLayout->addWidget(labela18Tab1);
            scrollLayout->addWidget(textTab1Edit18);

            QLabel *labela19Tab1 = new QLabel(("Текст 19:"), scrollWidget);
            scrollLayout->addWidget(labela19Tab1);
            scrollLayout->addWidget(textTab1Edit19);

            QLabel *labela20Tab1 = new QLabel(("Текст 20:"), scrollWidget);
            scrollLayout->addWidget(labela20Tab1);
            scrollLayout->addWidget(textTab1Edit20);

            QLabel *labela21Tab1 = new QLabel(("Текст 21:"), scrollWidget);
            scrollLayout->addWidget(labela21Tab1);
            scrollLayout->addWidget(textTab1Edit21);

            QLabel *labela22Tab1 = new QLabel(("Текст 22:"), scrollWidget);
            scrollLayout->addWidget(labela22Tab1);
            scrollLayout->addWidget(textTab1Edit22);

            QLabel *labela23Tab1 = new QLabel(("Текст 23:"), scrollWidget);
            scrollLayout->addWidget(labela23Tab1);
            scrollLayout->addWidget(textTab1Edit23);

            QLabel *labela24Tab1 = new QLabel(("Текст 24:"), scrollWidget);
            scrollLayout->addWidget(labela24Tab1);
            scrollLayout->addWidget(textTab1Edit24);

            QLabel *labela25Tab1 = new QLabel(("Текст 25:"), scrollWidget);
            scrollLayout->addWidget(labela25Tab1);
            scrollLayout->addWidget(textTab1Edit25);

            QLabel *labela26Tab1 = new QLabel(("Текст 26:"), scrollWidget);
            scrollLayout->addWidget(labela26Tab1);
            scrollLayout->addWidget(textTab1Edit26);

            QLabel *labela27Tab1 = new QLabel(("Текст 27:"), scrollWidget);
            scrollLayout->addWidget(labela27Tab1);
            scrollLayout->addWidget(textTab1Edit27);

            QLabel *labela28Tab1 = new QLabel(("Текст 28:"), scrollWidget);
            scrollLayout->addWidget(labela28Tab1);
            scrollLayout->addWidget(textTab1Edit28);

            QLabel *labela29Tab1 = new QLabel(("Текст 29:"), scrollWidget);
            scrollLayout->addWidget(labela29Tab1);
            scrollLayout->addWidget(textTab1Edit29);

//    // делаю поля только для чтения
    textTab1Edit1->setReadOnly(true);
    textTab1Edit2->setReadOnly(true);
    textTab1Edit3->setReadOnly(true);
    textTab1Edit4->setReadOnly(true);
    textTab1Edit5->setReadOnly(true);
    textTab1Edit6->setReadOnly(true);
    textTab1Edit7->setReadOnly(true);
    textTab1Edit8->setReadOnly(true);
    textTab1Edit9->setReadOnly(true);
    textTab1Edit10->setReadOnly(true);
    textTab1Edit11->setReadOnly(true);
    textTab1Edit12->setReadOnly(true);
    textTab1Edit13->setReadOnly(true);
    textTab1Edit14->setReadOnly(true);
    textTab1Edit15->setReadOnly(true);
    textTab1Edit16->setReadOnly(true);
    textTab1Edit17->setReadOnly(true);
    textTab1Edit18->setReadOnly(true);
    textTab1Edit19->setReadOnly(true);
    textTab1Edit20->setReadOnly(true);
    textTab1Edit21->setReadOnly(true);
    textTab1Edit22->setReadOnly(true);
    textTab1Edit23->setReadOnly(true);
    textTab1Edit24->setReadOnly(true);
    textTab1Edit25->setReadOnly(true);
    textTab1Edit26->setReadOnly(true);
    textTab1Edit27->setReadOnly(true);
    textTab1Edit28->setReadOnly(true);
    textTab1Edit29->setReadOnly(true);

   // scrollLayout->addWidget(labela1Tab1);
  //  scrollLayout->addWidget(textTab1Edit1);
   // scrollLayout->addWidget(labela2Tab1);
   // scrollLayout->addWidget(textTab1Edit2);

//    tab1Layout->addWidget(labela13Tab1);
//    tab1Layout->addWidget(textTab1Edit13);
//    tab1Layout->addWidget(labela14Tab1);
//    tab1Layout->addWidget(textTab1Edit14);
//    tab1Layout->addWidget(labela15Tab1);
//    tab1Layout->addWidget(textTab1Edit15);
//    tab1Layout->addWidget(labela16Tab1);
//    tab1Layout->addWidget(textTab1Edit16);
//    tab1Layout->addWidget(labela17Tab1);
//    tab1Layout->addWidget(textTab1Edit17);
//    tab1Layout->addWidget(labela18Tab1);
//    tab1Layout->addWidget(textTab1Edit18);
//    tab1Layout->addWidget(labela19Tab1);
//    tab1Layout->addWidget(textTab1Edit19);
//    tab1Layout->addWidget(labela20Tab1);
//    tab1Layout->addWidget(textTab1Edit20);
//    tab1Layout->addWidget(labela21Tab1);
//    tab1Layout->addWidget(textTab1Edit21);
//    tab1Layout->addWidget(labela22Tab1);
//    tab1Layout->addWidget(textTab1Edit22);
//    tab1Layout->addWidget(labela23Tab1);
//    tab1Layout->addWidget(textTab1Edit23);
//    tab1Layout->addWidget(labela24Tab1);
//    tab1Layout->addWidget(textTab1Edit24);
//    tab1Layout->addWidget(labela25Tab1);
//    tab1Layout->addWidget(textTab1Edit25);
//    tab1Layout->addWidget(labela26Tab1);
//    tab1Layout->addWidget(textTab1Edit26);
//    tab1Layout->addWidget(labela27Tab1);
//    tab1Layout->addWidget(textTab1Edit27);
//    tab1Layout->addWidget(labela28Tab1);
//    tab1Layout->addWidget(textTab1Edit28);
//    tab1Layout->addWidget(labela29Tab1);
//    tab1Layout->addWidget(textTab1Edit29);

//      // tab1Layout->addWidget(pTeTab1);
   // tab1Layout->addStretch(1);
scrollLayout->addStretch(1);


    QVBoxLayout *tab2Layout = new QVBoxLayout(tab2);
//    scrollArea = new QScrollArea(tab2);
//        textTab2Edit1 = new QTextEdit(scrollArea);

    textTab2Edit1 = new QTextEdit(tab2);
    textTab2Edit1->setObjectName("TextEdit1Tab2");
    textTab2Edit2 = new QTextEdit(tab2);
    textTab2Edit2->setObjectName("TextEdit2Tab2");
    textTab2Edit3 = new QTextEdit(tab2);
    textTab2Edit3->setObjectName("TextEdit3Tab2");
    textTab2Edit4 = new QTextEdit(tab2);
    textTab2Edit4->setObjectName("TextEdit4Tab2");
    textTab2Edit5 = new QTextEdit(tab2);
    textTab2Edit5->setObjectName("TextEdit5Tab2");

//    scrollArea->setWidget(textTab1Edit1);
//       scrollArea->setWidgetResizable(true);
//       scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
//       tab1Layout->addWidget(scrollArea);
tab2->setLayout( tab2Layout );


    QLabel *labelb1Tab2 = new QLabel(("Текст 1:"), tab2);
    QLabel *labelb2Tab2 = new QLabel(("Текст 2:"), tab2);
    QLabel *labelb3Tab2 = new QLabel(("Текст 3:"), tab2);
    QLabel *labelb4Tab2 = new QLabel(("Текст 4:"), tab2);
    QLabel *labelb5Tab2 = new QLabel(("Текст 5:"), tab2);

    textTab2Edit1->setReadOnly(true);
    textTab2Edit2->setReadOnly(true);
    textTab2Edit3->setReadOnly(true);
    textTab2Edit4->setReadOnly(true);
    textTab2Edit5->setReadOnly(true);

    tab2Layout->addWidget(labelb1Tab2);
    tab2Layout->addWidget(textTab2Edit1);
    tab2Layout->addWidget(labelb2Tab2);
    tab2Layout->addWidget(textTab2Edit2);
    tab2Layout->addWidget(labelb3Tab2);
    tab2Layout->addWidget(textTab2Edit3);
    tab2Layout->addWidget(labelb4Tab2);
    tab2Layout->addWidget(textTab2Edit4);
    tab2Layout->addWidget(labelb5Tab2);
    tab2Layout->addWidget(textTab2Edit5);

    tab2Layout->addStretch(1);


    QVBoxLayout *tab3Layout = new QVBoxLayout(tab3);
    textTab3Edit1 = new QTextEdit(tab3);
    textTab3Edit1->setObjectName("TextEdit1Tab3");
    textTab3Edit2 = new QTextEdit(tab3);
    textTab3Edit2->setObjectName("TextEdit2Tab3");
    textTab3Edit3 = new QTextEdit(tab3);
    textTab3Edit3->setObjectName("TextEdit3Tab3");
    textTab3Edit4 = new QTextEdit(tab3);
    textTab3Edit4->setObjectName("TextEdit4Tab3");


tab3->setLayout( tab3Layout );

    QLabel *labelc1Tab3 = new QLabel(("Текст 1:"), tab3);
    QLabel *labelc2Tab3 = new QLabel(("Текст 2:"), tab3);
    QLabel *labelc3Tab3 = new QLabel(("Текст 3:"), tab3);
    QLabel *labelc4Tab3 = new QLabel(("Текст 4:"), tab3);

    textTab3Edit1->setReadOnly(true);
    textTab3Edit2->setReadOnly(true);
    textTab3Edit3->setReadOnly(true);
    textTab3Edit4->setReadOnly(true);

    // устанавливаю layouts
    tab3Layout->addWidget(labelc1Tab3);
    tab3Layout->addWidget(textTab3Edit1);
    tab3Layout->addWidget(labelc2Tab3);
    tab3Layout->addWidget(textTab3Edit2);
    tab3Layout->addWidget(labelc3Tab3);
    tab3Layout->addWidget(textTab3Edit3);
    tab3Layout->addWidget(labelc4Tab3);
    tab3Layout->addWidget(textTab3Edit4);

    tab3Layout->addStretch(1);

    QVBoxLayout *tab4Layout = new QVBoxLayout(tab4);
    textTab4Edit1 = new QTextEdit(tab4);
    textTab4Edit1->setObjectName("TextEdit1Tab4");
    textTab4Edit2 = new QTextEdit(tab4);
    textTab4Edit2->setObjectName("TextEdit2Tab4");
    textTab4Edit3 = new QTextEdit(tab4);
    textTab4Edit3->setObjectName("TextEdit3Tab4");
    textTab4Edit4 = new QTextEdit(tab4);
    textTab4Edit4->setObjectName("TextEdit4Tab4");
    textTab4Edit5 = new QTextEdit(tab4);
    textTab4Edit5->setObjectName("TextEdit5Tab4");



tab4->setLayout( tab4Layout );


    QLabel *labelc1Tab4 = new QLabel(("Текст 1:"), tab4);
    QLabel *labelc2Tab4 = new QLabel(("Текст 2:"), tab4);
    QLabel *labelc3Tab4 = new QLabel(("Текст 3:"), tab4);
    QLabel *labelc4Tab4 = new QLabel(("Текст 4:"), tab4);
    QLabel *labelc5Tab4 = new QLabel(("Текст 5:"), tab4);

    textTab4Edit1->setReadOnly(true);
    textTab4Edit2->setReadOnly(true);
    textTab4Edit3->setReadOnly(true);
    textTab4Edit4->setReadOnly(true);
    textTab4Edit5->setReadOnly(true);

    // устанавливаю layouts
    tab4Layout->addWidget(labelc1Tab4);
    tab4Layout->addWidget(textTab4Edit1);
    tab4Layout->addWidget(labelc2Tab4);
    tab4Layout->addWidget(textTab4Edit2);
    tab4Layout->addWidget(labelc3Tab4);
    tab4Layout->addWidget(textTab4Edit3);
    tab4Layout->addWidget(labelc4Tab4);
    tab4Layout->addWidget(textTab4Edit4);
    tab4Layout->addWidget(labelc5Tab4);
    tab4Layout->addWidget(textTab4Edit5);

    tab4Layout->addStretch(1);

    QVBoxLayout *tab5Layout = new QVBoxLayout(tab5);
    textTab5Edit1 = new QTextEdit(tab5);
    textTab5Edit1->setObjectName("TextEdit1Tab5");
    textTab5Edit2 = new QTextEdit(tab5);
    textTab5Edit2->setObjectName("TextEdit2Tab5");
    textTab5Edit3 = new QTextEdit(tab5);
    textTab5Edit3->setObjectName("TextEdit3Tab5");
    textTab5Edit4 = new QTextEdit(tab5);
    textTab5Edit4->setObjectName("TextEdit4Tab5");
    textTab5Edit5 = new QTextEdit(tab5);
    textTab5Edit5->setObjectName("TextEdit5Tab5");
    textTab5Edit6 = new QTextEdit(tab5);
    textTab5Edit6->setObjectName("TextEdit6Tab5");
    textTab5Edit7 = new QTextEdit(tab5);
    textTab5Edit7->setObjectName("TextEdit7Tab5");



tab5->setLayout( tab5Layout );

    QLabel *labelc1Tab5 = new QLabel(("Текст 1:"), tab5);
    QLabel *labelc2Tab5 = new QLabel(("Текст 2:"), tab5);
    QLabel *labelc3Tab5 = new QLabel(("Текст 3:"), tab5);
    QLabel *labelc4Tab5 = new QLabel(("Текст 4:"), tab5);
    QLabel *labelc5Tab5 = new QLabel(("Текст 5:"), tab5);
    QLabel *labelc6Tab5 = new QLabel(("Текст 6:"), tab5);
    QLabel *labelc7Tab5 = new QLabel(("Текст 7:"), tab5);

    textTab5Edit1->setReadOnly(true);
    textTab5Edit2->setReadOnly(true);
    textTab5Edit3->setReadOnly(true);
    textTab5Edit4->setReadOnly(true);
    textTab5Edit5->setReadOnly(true);
    textTab5Edit6->setReadOnly(true);
    textTab5Edit7->setReadOnly(true);


    // устанавливаю layouts
    tab5Layout->addWidget(labelc1Tab5);
    tab5Layout->addWidget(textTab5Edit1);
    tab5Layout->addWidget(labelc2Tab5);
    tab5Layout->addWidget(textTab5Edit2);
    tab5Layout->addWidget(labelc3Tab5);
    tab5Layout->addWidget(textTab5Edit3);
    tab5Layout->addWidget(labelc4Tab5);
    tab5Layout->addWidget(textTab5Edit4);
    tab5Layout->addWidget(labelc5Tab5);
    tab5Layout->addWidget(textTab5Edit5);
    tab5Layout->addWidget(labelc6Tab5);
    tab5Layout->addWidget(textTab5Edit6);
    tab5Layout->addWidget(labelc7Tab5);
    tab5Layout->addWidget(textTab5Edit7);

    tab5Layout->addStretch(1);

    QVBoxLayout *tab6Layout = new QVBoxLayout(tab6);
    textTab6Edit1 = new QTextEdit(tab6);
    textTab6Edit1->setObjectName("TextEdit1Tab6");
//    textTab6Edit2 = new QTextEdit(tab6);
//    textTab6Edit2->setObjectName("TextEdit2Tab6");



tab6->setLayout( tab6Layout );

    QLabel *labelc1Tab6 = new QLabel(("text1"), tab6);
//    QLabel *labelc2Tab6 = new QLabel(("Текст 2:"), tab6);

    textTab6Edit1->setReadOnly(true);
//    textTab6Edit2->setReadOnly(true);



    // устанавливаю layouts
    tab6Layout->addWidget(labelc1Tab6);
    tab6Layout->addWidget(textTab6Edit1);
//    tab6Layout->addWidget(labelc2Tab6);
//    tab6Layout->addWidget(textTab6Edit2);


    tab6Layout->addStretch(1);
}

/// задаем модель данных
void MainWindow::setModel( VFVPModel &vfvpmodel )
{
    
    vfvpmodel.charVfvp.vfvp_kod = "18200000000000040";
    
    vfvpmodel.charVfvp.vfvp_org = "18200000004000040";
    /
    vfvpmodel.charVfvp.vfvp_dt  = QDateTime::currentDateTime();

    POSVFVP posVfvp; /// инициализируем модель данных положения 
    
    posVfvp.description = QString( "p" );
    /
    posVfvp.latitude    = QString( "5." );
    
    posVfvp.longitude   = QString( "4." );
    
    posVfvp.height      = QString( "404" );
    
    posVfvp.OK          = QString( "П" );
    
    vfvpmodel.posVfvpLst.append( posVfvp );

    LSVFVP lsVfvp; /
    /
    lsVfvp.description = QString( "лич" );
    /
    lsVfvp.kolshtat    = QString( "300" );
    /// 
    lsVfvp.kolnal      = QString( "30" );
    
    lsVfvp.ukompl      = QString( "3" );
    /
    vfvpmodel.lsVfvpLst.append( lsVfvp );

    VVTVFVP vvtVfvp; //
    /// н
    vvtVfvp.description = QString( "В" );
    /// к
    vvtVfvp.kkoovt_kod  = QString( "50" ); /
    /// к
    vvtVfvp.kolshtat    = QString( "30" );
    /// к
    vvtVfvp.kolnal      = QString( "30" );
    /// уко
    vvtVfvp.ukompl      = QString( "3" );
    /// д
    vfvpmodel.vvtVfsvLst.append( vvtVfvp );

    

    /// 
    TXFDataWorker *txfDataWorker = new TXFDataWorker();
   
    txfDataWorker->setKEY( "V772" );
    /// код знака ( код серии знаков )
    txfDataWorker->setCOD( "77012" );
    /// 
    txfDataWorker->setCOD_TYPE( "VEC" );
    ///
    /// коо
    txfDataWorker->setMETValue( "5573", "41885365" );
    //
    txfDataWorker->setMETValue( "5333", "453903" );
    /// се
    /// надпись
    txfDataWorker->setSEMValue( "50", "1" );
    /// н
    txfDataWorker->setSEMValue( "92", "К" );
    /// д
    vfvpmodel.txfDataLst.append( txfDataWorker );
}

void MainWindow::onTreeViewItemClicked(const QModelIndex &modelIndex)
{

//        QString text;

//        // Заполняет выборочно
//        if (modelIndex.row() == 0)
//        {
////         textTab1Edit1->setText( modelIndex.data().toString() );
//         text = QString("Текст 1 вставка");
//         text =  modelIndex.data().toString();
//         textTab1Edit1->setText(text);
//        }
//        else if (modelIndex.row() == 1)
//        {
//            text = QString("Текст 2 вставка");
//        }
//        else if (modelIndex.row() == 2)
//        {
//            text = QString("Текст 3 вставка");
//            textTab3Edit3->setText(text);
//        }

        // выбор полей для заполнения
//        textTab1Edit1->setText(text);
//        textTab1Edit2->setText(text);
//        textTab2Edit3->setText(text);

//    // получаем текст элемента дерева
      //QMap<Int, QVariant> (QAbstractitemModel)
//    QString text = model->itemData(modelIndex).value(Qt::DisplayRole).toString();
//        // вставляем текст в соответствующее поле вкладки
//        if (text == "Текст 1")
//        {
//            textTab1Edit1->setText("Текст для Tab 1, TextEdit 1");
//        }
//        else if (text == "Текст 2")
//        {
//            textTab1Edit2->setText("Текст для Tab 1, TextEdit 2");
//        }
//        else if (text == "Вложенный текст")
//        {
//            textTab1Edit3->setText("Текст для Tab 1, TextEdit 3");
//        }
//        else if (text == "Вложенный текст")
//        {
//            textTab2Edit3->setText("Текст для Tab 2, TextEdit 3");
//        }
        // QList<QVariant> (QAbstractitemModel) с первого значения at(0)
//        QString text = model->itemData(modelIndex).values().at(0).toString();

//        // проверяю какая вкладка активна и устанавливаю текст
//        if (tabWidget->currentIndex() == 0)
//        {
//            textTab1Edit1->setText(text);
//        }
//        else if (tabWidget->currentIndex() == 1)
//        {
//            text = QString("Текст 3 вставка");
//            textTab1Edit3->setText(text);
//        }
//        QTextEdit *pTextEdit1 = centralWidget()->findChild < QTextEdit* > ( "TextEditTab1" );
//        QTextEdit *pTextEdit2 = centralWidget()->findChild < QTextEdit* > ( "qTextEdit2" );


//        qDebug() << __PRETTY_FUNCTION__ << pTextEdit1->objectName();
        // пример
        qDebug() << __PRETTY_FUNCTION__ << modelIndex.data(Qt::UserRole).toString();
//        qDebug() << __PRETTY_FUNCTION__ << pTextEdit2->objectName();

//        pTextEdit1->setText( modelIndex.data().toString());
//        pTextEdit2->setText( "TextEdit 2 new" );
//  textTab1Edit1->setText( modelIndex.data().toString() );
//  textTab1Edit2->setText( modelIndex.data().toString() );
//  textTab1Edit3->setText( modelIndex.data().toString() );
//  textTab2Edit3->setText( modelIndex.data().toString() );
        qDebug() << "П";

        /// характеристики ВФВП [ vfvp ]
        qDebug() << "ха [ v ]:";
        qDebug() << "vfvp_kod => " << vfvpmodel.charVfvp.vfvp_kod;
        qDebug() << "vfvp_org => " << vfvpmodel.charVfvp.vfvp_org;
        qDebug() << "vfvp_dt  => " << vfvpmodel.charVfvp.vfvp_dt;

        /// характеристики ВФВП [ vfvp ] => modelView
        textTab1Edit1->setText( vfvpmodel.charVfvp.vfvp_kod );
        textTab1Edit2->setText( vfvpmodel.charVfvp.vfvp_dlkod );
        textTab1Edit3->setText( vfvpmodel.charVfvp.vfvp_dt.toString() );
        textTab1Edit4->setText( vfvpmodel.charVfvp.vfvp_num );
        textTab1Edit5->setText( vfvpmodel.charVfvp.ktvfig_kod );
        textTab1Edit6->setText( vfvpmodel.charVfvp.kvvsig_kod );
        textTab1Edit7->setText( vfvpmodel.charVfvp.krvig_kod );
        textTab1Edit8->setText( vfvpmodel.charVfvp.vfvp_org );
        textTab1Edit9->setText( vfvpmodel.charVfvp.oksm_kod );
        textTab1Edit10->setText( vfvpmodel.charVfvp.ksmt_kod );
        textTab1Edit11->setText( vfvpmodel.charVfvp.kuvf_kod );
        textTab1Edit12->setText( vfvpmodel.charVfvp.ktor_kod );
        textTab1Edit13->setText( vfvpmodel.charVfvp.vfvp_name );
        textTab1Edit14->setText( vfvpmodel.charVfvp.vfvp_sname );
        textTab1Edit15->setText( vfvpmodel.charVfvp.vfvp_kod_esutz );
        textTab1Edit16->setText( vfvpmodel.charVfvp.vfvp_vro.toString() );
        textTab1Edit17->setText( vfvpmodel.charVfvp.vfvp_numc );
        textTab1Edit18->setText( vfvpmodel.charVfvp.vfvp_numcnew );
        textTab1Edit19->setText( vfvpmodel.charVfvp.ksuo_kod );
        textTab1Edit20->setText( vfvpmodel.charVfvp.kpo_kod );
        textTab1Edit21->setText( vfvpmodel.charVfvp.kio_kod );
        textTab1Edit22->setText( vfvpmodel.charVfvp.kdo_kod );
        textTab1Edit23->setText( vfvpmodel.charVfvp.kir_kod );
        textTab1Edit24->setText( vfvpmodel.charVfvp.vfvp_bp );
        textTab1Edit25->setText( vfvpmodel.charVfvp.vfvp_importance );
        textTab1Edit26->setText( vfvpmodel.charVfvp.vfvp_info );
        textTab1Edit27->setText( vfvpmodel.charVfvp.kod_khdvf );
        textTab1Edit28->setText( vfvpmodel.charVfvp.kod_ksbs );
        textTab1Edit29->setText( vfvpmodel.charVfvp.height );

        /// по
        qDebug() << "положение воинского формирования [ pvfvp ]:";
        qDebug() << "description => " << vfvpmodel.posVfvpLst.value( 0 ).description;
        qDebug() << "latitude    => " << vfvpmodel.posVfvpLst.value( 0 ).latitude;
        qDebug() << "longitude   => " << vfvpmodel.posVfvpLst.value( 0 ).longitude;
        qDebug() << "height      => " << vfvpmodel.posVfvpLst.value( 0 ).height;
        qDebug() << "OK          => " << vfvpmodel.posVfvpLst.value( 0 ).OK;

        textTab2Edit1->setText( vfvpmodel.posVfvpLst.value( 0 ).description );
        textTab2Edit2->setText( vfvpmodel.posVfvpLst.value( 0 ).latitude );
        textTab2Edit3->setText( vfvpmodel.posVfvpLst.value( 0 ).longitude);
        textTab2Edit4->setText( vfvpmodel.posVfvpLst.value( 0 ).height );
        textTab2Edit5->setText( vfvpmodel.posVfvpLst.value( 0 ).OK );

        /// пол


        /// ли
        qDebug() << "лfvp ]:";
        qDebug() << "description => " << vfvpmodel.lsVfvpLst.value( 0 ).description;
        qDebug() << "kolshtat    => " << vfvpmodel.lsVfvpLst.value( 0 ).kolshtat;
        qDebug() << "kolnal      => " << vfvpmodel.lsVfvpLst.value( 0 ).kolnal;
        qDebug() << "ukompl      => " << vfvpmodel.lsVfvpLst.value( 0 ).ukompl;

        textTab3Edit1->setText( vfvpmodel.lsVfvpLst.value( 0 ).description );
        textTab3Edit2->setText( vfvpmodel.lsVfvpLst.value( 0 ).kolshtat );
        textTab3Edit3->setText( vfvpmodel.lsVfvpLst.value( 0 ).kolnal );
        textTab3Edit4->setText( vfvpmodel.lsVfvpLst.value( 0 ).ukompl );

        /// В]
        qDebug() << "ВТ [ vvtvfvp ]:";
        qDebug() << "description => " << vfvpmodel.vvtVfsvLst.value( 0 ).description;
        qDebug() << "kkoovt_kod  => " << vfvpmodel.vvtVfsvLst.value( 0 ).kkoovt_kod;
        qDebug() << "k   => " << vfvpmodel.vvtVfsvLst.value( 0 ).kolshtat;
        qDebug() << "kolnal      => " << vfvpmodel.vvtVfsvLst.value( 0 ).kolnal;
        qDebug() << "ukompl      => " << vfvpmodel.vvtVfsvLst.value( 0 ).ukompl;

        textTab4Edit1->setText( vfvpmodel.vvtVfsvLst.value( 0 ).description );
        textTab4Edit2->setText( vfvpmodel.vvtVfsvLst.value( 0 ).kkoovt_kod );
        textTab4Edit3->setText( vfvpmodel.vvtVfsvLst.value( 0 ).kolshtat );
        textTab4Edit4->setText( vfvpmodel.vvtVfsvLst.value( 0 ).kolnal );
        textTab4Edit5->setText( vfvpmodel.vvtVfsvLst.value( 0 ).ukompl );

        /// к
        qDebug() << "картографические данные [ kdou ]:";
        qDebug() << "KEY      => " << vfvpmodel.txfDataLst.value( 0 )->getKEY();
        qDebug() << "COD      => " << vfvpmodel.txfDataLst.value( 0 )->getCOD();
        qDebug() << "COD_TYPE => " << vfvpmodel.txfDataLst.value( 0 )->getCOD_TYPE();
        qDebug() << "MET 1    => " << vfvpmodel.txfDataLst.value( 0 )->getMET().first();
        qDebug() << "MET 2    => " << vfvpmodel.txfDataLst.value( 0 )->getMET().at( 1 );
        QString semKey( vfvpmodel.txfDataLst.value( 0 )->getSEMList().first() );
        qDebug() << "SEM 1    => " << semKey << vfvpmodel.txfDataLst.value( 0 )->getSEMValue( semKey );
        semKey = vfvpmodel.txfDataLst.value( 0 )->getSEMList().at( 1 );
        qDebug() << "SEM 2    => " << semKey << vfvpmodel.txfDataLst.value( 0 )->getSEMValue( semKey );

        textTab5Edit1->setText( vfvpmodel.txfDataLst.value( 0 )->getKEY() );
        textTab5Edit2->setText( vfvpmodel.txfDataLst.value( 0 )->getCOD() );
        textTab5Edit3->setText( vfvpmodel.txfDataLst.value( 0 )->getCOD_TYPE() );
        //textTab5Edit4->setText( vfvpmodel.txfDataLst.value( 0 )->getMET().first());
        //textTab5Edit5->setText( vfvpmodel.txfDataLst.value( 0 )->getMET().at( 1 ).toString() );
        textTab5Edit6->setText( vfvpmodel.txfDataLst.value( 0 )->getSEMValue( semKey ) );
        textTab5Edit7->setText( vfvpmodel.txfDataLst.value( 0 )->getSEMValue( semKey ) );

        /// картографические данные [ kdou ] ( txf )
        qDebug() << "к:";
        qDebug() << vfvpmodel.txfDataLst.at( 0 )->createTxfData().toStdString().c_str();

        textTab6Edit1->setText( vfvpmodel.txfDataLst.at( 0 )->createTxfData().toStdString().c_str() );


}
