#include <QFile>
#include <QTextStream>
#include "configwindow.h"
#include<QVBoxLayout>
#include <QDialog>
#include <QFile>
#include <QLabel>
#include <QFormLayout>
#include <QPushButton>

ConfigWindow::ConfigWindow(QWidget *parent)
    : QDialog(parent)/*, fieldsEnabled(true)*/
{

    setWindowTitle("Настройка сети"); // Установка заголовка окна
    setFixedSize(500, 200);

    labelIp = new QLabel("ipAddress", this);
    lineEditIp = new QLineEdit(this);
    labelPort = new QLabel("port", this);
    lineEditPort = new QLineEdit(this);

    // Прочитать текст из файла config.txt
        loadFromFile();

        // Вызов функции для блокировки полей

//    // Прочитать текст из файла config.txt
//    QFile file("config.txt");
//    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
//    {
//        QTextStream in(&file);
//        QString text = in.readAll();
//        lineEditIp->setText(text);
//        lineEditPort->setText(text);
//        originalText = text; // Сохранить оригинальный текст
//        file.close();
//    }
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    QFormLayout *formLayout = new QFormLayout(this);
    formLayout->addRow(labelIp, lineEditIp);
    formLayout->addRow(labelPort, lineEditPort);
    mainLayout->addLayout(formLayout);
    QHBoxLayout *buttonLayout = new QHBoxLayout();
    buttonLayout->addStretch(); // Add a stretch spacer

    saveButton = new QPushButton(" Сохранить ", this);
    saveButton->setFixedSize(saveButton->sizeHint());

    connect(saveButton, &QPushButton::clicked, this, &ConfigWindow::saveToFile);

    buttonLayout->addWidget(saveButton);
    cancelButton = new QPushButton(" Отменить ввод ", this);
    cancelButton->setFixedSize(cancelButton->sizeHint());
    connect(cancelButton, &QPushButton::clicked, this, &ConfigWindow::cancelChanges);

    buttonLayout->addWidget(cancelButton);
    mainLayout->addStretch(1);
    mainLayout->addLayout(buttonLayout);

    // Создание чекбокса
    checkBox = new QCheckBox("Изменить", this);
    checkBox->setChecked(false);

    connect(checkBox, &QCheckBox::stateChanged, this, &ConfigWindow::toggleFields);
    // connect(checkBox, &QCheckBox::stateChanged, this, [this](int state) {

    //       });
    // Добавление чекбокса в основной макет
    mainLayout->addWidget(checkBox);
    toggleFields();
}

//setFixedSize(300, 100);

//QLabel *label = new QLabel("ipAddress", dialog);
//lineEdit = new QLineEdit(dialog);

//// Прочитать текст из файла config.txt
//QFile file("config.txt");
//if (file.open(QIODevice::ReadOnly | QIODevice::Text))
//{
//    QTextStream in(&file);
//    QString text = in.readAll();
//    lineEdit->setText(text);
//    QString line;
//    while (!in.atEnd())
//    {
//        line = in.readLine();
//        // Проверяем условие для выбора нужной строки
//        if (line.startsWith("IP:"))
//        {
//            line.remove("IP: "); // Удаляем префикс, если нужно
//            lineEdit->setText(line);
//            break;
//        }
//    }
//    ///////////////
//    file.close();
//}

//            QFormLayout *formLayout = new QFormLayout(dialog);
//            formLayout->addRow(label, lineEdit);

//            dialog->exec();
//}

void ConfigWindow::saveToFile()
{
    QString ipAddress = lineEditIp->text();
        QString port = lineEditPort->text();

        // Записать текст в файл config.txt
        QFile file("config.txt");
        if (file.open(QIODevice::WriteOnly | QIODevice::Text))
        {
            QTextStream out(&file);
            out << "IP " << ipAddress << Qt::endl;
            out << "port " << port << Qt::endl;
            file.close();
        }

        originalText = ipAddress; // Обновить оригинальный текст
//    QString text = lineEditIp->text();
//    QString port = lineEditPort->text();
//    // Записать текст в файл config.txt
//    QFile file("config.txt");
//    if (file.open(QIODevice::WriteOnly | QIODevice::Text))
//    {
//        QTextStream out(&file);
//        out << text;
//        file.close();
//    }
    //rezet
//    // Обновить содержимое lineEdit из файла config.txt
//    QFile readFile("config.txt");
//    if (readFile.open(QIODevice::ReadOnly | QIODevice::Text))
//    {
//        QTextStream in(&readFile);
//        QString newText = in.readAll();
//        lineEdit->setText(newText);
//        readFile.close();
//    }

  //  originalText = text; // Обновить оригинальный текст
}
void ConfigWindow::cancelChanges()
{

     qDebug() << "Original IP Text:" << originalText;
     // Загрузить оригинальный текст в lineEdit
    lineEditIp->setText(originalText);
    lineEditPort->setText(originalText);
    loadFromFile();
}

//void ConfigWindow::loadFromFile()
//{
//    QString ipAddressFromFile = "Read from file";
//       QString portFromFile = "Read from file";

//       lineEditIp->setText(ipAddressFromFile);
//       lineEditPort->setText(portFromFile);
//}
void ConfigWindow::loadFromFile()
{
    QFile file("config.txt"); // Путь к вашему файлу
    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream in(&file);
        QString ipAddressFromFile;
        QString portFromFile;

        while (!in.atEnd())
        {
            QString line = in.readLine();

            if (line.startsWith("IP"))
            {
                ipAddressFromFile = line.mid(3).trimmed();
            }
            else if (line.startsWith("port"))
            {
                portFromFile = line.mid(5).trimmed();
            }
        }

        file.close();

        lineEditIp->setText(ipAddressFromFile);
        lineEditPort->setText(portFromFile);
       // originalText = ipAddressFromFile; //  Сохранить оригинальный текст  для IP-адреса
       //  originalText = portFromFile; //  Сохранить оригинальный текст  для IP-адреса
    }
}
//void ConfigWindow::toggleFields(int state)
//{

//   bool enabled = (fieldsEnabled && (state == Qt::Checked));
//    lineEditIp->setEnabled(enabled);
//    lineEditPort->setEnabled(enabled);
//}
void ConfigWindow::toggleFields()
{
    bool enabled = checkBox->isChecked();
    lineEditIp->setEnabled(enabled);
    lineEditPort->setEnabled(enabled);
}
