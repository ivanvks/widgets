#ifndef CONFIGWINDOW_H
#define CONFIGWINDOW_H
#include <QDialog>
#include <QLineEdit>
#include <QLineEdit>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QCheckBox>

class ConfigWindow : public QDialog
{
    Q_OBJECT

public:
    ConfigWindow(QWidget *parent = nullptr);

private slots:
    void saveToFile();
    void cancelChanges();
  // void toggleFields(int state);
    void loadFromFile();
   void toggleFields();
//    void toggleFields();


private:
     QCheckBox* checkBox;
//    bool fieldsEnabled;
     QLabel *labelIp;
     QLabel *labelPort;
     QLineEdit *lineEditIp;
     QLineEdit *lineEditPort;
     QPushButton *saveButton;
     QPushButton *cancelButton;
     QString originalText;
};

#endif // CONFIGWINDOW_H
