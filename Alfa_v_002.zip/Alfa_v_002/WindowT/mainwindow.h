#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QTabWidget>
#include <QPushButton>
#include <QLabel>
#include "connectdatabase.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

private slots:
    void openNewWindow();
    void updateDatabaseConnectionStatus(bool connected);
private:
    QTabWidget *tabWidget;
     QPushButton *button;
      QLabel* connectionStatusIcon;

   ConnectDatabase *connectDatabase;



};
#endif // MAINWINDOW_H
