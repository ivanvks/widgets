#include "connectdatabase.h"
#include <QSettings>
#include <QtSql/QSqlDatabase>
ConnectDatabase::ConnectDatabase(QObject *parent)
    : QObject{parent}
{

}
void ConnectDatabase::checkDatabaseConnection()
{
    QSettings settings("config.conf", QSettings::IniFormat);

    QString host = settings.value("DataBase/host").toString();
    int port = settings.value("DataBase/port").toInt();
    QString databaseName = settings.value("DataBase/name").toString();
    QString userName = settings.value("DataBase/user").toString();
    QString password = settings.value("DataBase/pass").toString();

    bool connected = connectToDatabase(host, port, databaseName, userName, password);

    emit databaseConnected(connected);
}

bool ConnectDatabase::connectToDatabase(const QString &host, int port, const QString &databaseName,
                                       const QString &userName, const QString &password)
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QPSQL");

    db.setHostName(host);
    db.setPort(port);
    db.setDatabaseName(databaseName);
    db.setUserName(userName);
    db.setPassword(password);

    bool connected = db.open();

    return connected;

//    if (db.open()) {
//            db.close();
//            return true;
//        } else {
//            return false;
//        }
}
