#ifndef CONFIGWINDOW_H
#define CONFIGWINDOW_H
#include <QDialog>
#include <QLineEdit>
#include <QLineEdit>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QCheckBox>

class ConfigWindow : public QDialog
{
    Q_OBJECT

public:
    ConfigWindow(QWidget *parent = nullptr);
void createDefaultSettings(const QString& configFilePath);
private slots:
    void saveToFile();
    void cancelChanges();
  // void toggleFields(int state);
    void loadFromFile();
   void toggleFields();
//    void toggleFields();


private:
 //  void createDefaultSettings(const QString& filePath);
     QCheckBox* checkBox;
//    bool fieldsEnabled;
     QLabel  *labelHostDb, *labelPortDb, *labelNameDb, *labelNameUserDb, *labelPassDb, *labelTarget, *labelWebHost;
     QLineEdit *lineHostDb, *lineEditPortDb, *lineNameDb, *lineEditNameUserDb, *lineEditPassDb, *lineEditTarget, *lineEditWebHost;

     QPushButton *saveButton;
     QPushButton *cancelButton;
     QString originalText;
};

#endif // CONFIGWINDOW_H
