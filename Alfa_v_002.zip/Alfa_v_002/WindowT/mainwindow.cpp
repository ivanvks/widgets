#include<QVBoxLayout>
#include <QDialog>
#include <QFile>
#include <QLabel>
#include <QFormLayout>
#include <QMessageBox>
#include <QPixmap>
#include "mainwindow.h"
#include "configwindow.h"
#include "connectdatabase.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    ///Создаем экземпляр класса ConfigWindow
   ConfigWindow configWindow;

    tabWidget = new QTabWidget(this);

    QWidget *tab1 = new QWidget();
    tabWidget->addTab(tab1, "Tab 1");

    QWidget *tab2 = new QWidget();
    tabWidget->addTab(tab2, "Tab 2");

    QWidget *tab3 = new QWidget();
    tabWidget->addTab(tab3, "Tab 3");
/////////////////////////////////////////////////////////////////
    button = new QPushButton(this);
    button->setToolTip("Настройка сети");
  // button->setFixedSize(70, 70);
   // button->setStyleSheet(" { border-radius: 100px; }");
  button->setIcon(QIcon(":/images/images/blue.png")); // Устанавливаем изображение иконки
   // button->setIcon(QIcon(":/blue"));
   button->setIconSize(QSize(40, 40));
  // button->setFixedSize(28, 28);
  // button->setStyleSheet("QPushButton { border: none;}");
  //  button->setStyleSheet(" { border: none;}");
  //  button->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);

   // QPushButton *button = new QPushButton("Open Window", this);
    int buttonSize = 40;  // Размер кнопки
    button->setFixedSize(buttonSize, buttonSize);
    int borderRadius = buttonSize / 2;  // Радиус скругления
  // button->setStyleSheet(QString("{ border-radius: %1px; }").arg(borderRadius));
    button->setStyleSheet(QString("QPushButton { border-radius: %1px; }").arg(borderRadius));


    connect(button, &QPushButton::clicked, this, &MainWindow::openNewWindow);

    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(centralWidget);
    layout->addWidget(button, 0, Qt::AlignTop | Qt::AlignRight);
   // layout->addWidget(button, 0, 4);
//////////////////////////////////////////////////////////////////////////////////////////////////////


//    // Создание иконки статуса подключения
//        connectionStatusIcon = new QLabel(this);
//        QPixmap icon(":/images/images/stat.png"); // Путь к изображению иконки подключения
//        QPixmap resizedIcon = icon.scaled(QSize(20, 20), Qt::KeepAspectRatio); // Изменение размера иконки
//        connectionStatusIcon->setPixmap(resizedIcon);
//        connectionStatusIcon->setAlignment(Qt::AlignCenter); // Выравнивание иконки по центру
//        connectionStatusIcon->move(300, 60); // Перемещение иконки статуса подключения

//        // Проверка подключения базы данных и установка соответствующей иконки статуса подключения
//        bool connected = checkDatabaseConnection();
//        updateDatabaseConnectionStatus(connected);



    connectionStatusIcon = new QLabel(this);
        QPixmap grayIcon(":/images/images/stat.png"); // Путь к изображению серой иконки
        //QPixmap grayIcon = icon.scaled(QSize(20, 20), Qt::KeepAspectRatio); // Изменение размера иконки
        connectionStatusIcon->setPixmap(grayIcon);
        connectionStatusIcon->setAlignment(Qt::AlignCenter); // Выравнивание иконки по центру

        QSpacerItem* spacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        // Создание горизонтального контейнера для размещения кнопки и иконки
         //  QHBoxLayout* layout = new QHBoxLayout;
         //  layout->addWidget(configButton);
           layout->addItem(spacer);
           layout->addWidget(connectionStatusIcon);

           // Создание основного виджета и установка горизонтального контейнера в качестве его макета
         //  QWidget* centralWidget = new QWidget(this);
           centralWidget->setLayout(layout);

/////////////////////////////////////////////////////////////////////////////////////////////////////////
        // Дополнительные настройки QLabel, если нужно

    layout->addWidget(tabWidget);

    setCentralWidget(centralWidget);
//////////////////////////////////////////////////////////////////////////////////////////////
    // Проверяем существует ли файл настроек
    QString configFilePath = "config.conf";
    //QString configFilePath = "D:/path/to/config.txt"; // Путь к файлу настроек

    // Проверяем наличие файла
    QFile file(configFilePath);
    if (!file.exists()) {
        configWindow.createDefaultSettings(configFilePath);
        // Файл не найден, выводим предупреждение
        QMessageBox::warning(nullptr, "Внимание!", "Файл настроек сети не найден. Будет создан файл настроек по умолчанию! "
                                                       "Если требуется внести изменения в настройки конфигурации сети, "
                                                       "внесите изменения в меню настроек!");

    }
    connectDatabase = new ConnectDatabase(this);
        connect(connectDatabase, &ConnectDatabase::databaseConnected, this, &MainWindow::updateDatabaseConnectionStatus);
        connectDatabase->checkDatabaseConnection();
}

void MainWindow::openNewWindow()
{
    ConfigWindow *configWindow = new ConfigWindow(this);
    configWindow->exec();
}

void MainWindow::updateDatabaseConnectionStatus(bool connected)
{
    if (connected) {
            QPixmap greenIcon(":/images/images/green.png"); // Путь к изображению зеленой иконки
            connectionStatusIcon->setPixmap(greenIcon);
        } else {
            QPixmap redIcon(":/images/images/red.png"); // Путь к изображению красной иконки
            connectionStatusIcon->setPixmap(redIcon);
        }
}
