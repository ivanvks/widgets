#include<QVBoxLayout>
#include <QMenuBar>
#include <QMenu>
#include <QDialog>
#include <QFile>
#include <QLabel>
#include <QFormLayout>
#include <QMessageBox>
#include <QPixmap>
#include <QDebug>
#include <QtSql/QSqlDatabase>
#include "mainwindow.h"
#include "configwindow.h"
#include "connectdatabase.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
createCustomMenu();
    tabWidget = new QTabWidget(this);

    QWidget *tab1 = new QWidget();
    tabWidget->addTab(tab1, "Tab 1");

    QWidget *tab2 = new QWidget();
    tabWidget->addTab(tab2, "Tab 2");

    QWidget *tab3 = new QWidget();
    tabWidget->addTab(tab3, "Tab 3");
    /// кнопка нового окна
    button = new QPushButton(this);
    button->setToolTip("Настройка сети");
    button->setIcon(QIcon(":/images/images/ellow.png")); // Устанавливаем изображение иконки
    button->setIconSize(QSize(23, 23));
    int buttonSize = 23;  // Размер кнопки
    button->setFixedSize(buttonSize, buttonSize);
    int borderRadius = buttonSize / 2;  // Радиус скругления
    button->setStyleSheet(QString("QPushButton { border-radius: %1px; }").arg(borderRadius));

/// кликнули сдесь - запустили новое окно и сигнал -settingsSaved() но при условии
///  когда вызывается saveToFile() ну по сути только когда мы нажимаем на кнопку сохранить
    connect(button, &QPushButton::clicked, this, &MainWindow::openNewWindow);

    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *layoutV = new QVBoxLayout(centralWidget);
    connectionStatusIcon = new QLabel(this);
    QPixmap   grayIcon(":/images/images/stat.png"); // Путь к изображению серой иконки
    connectionStatusIcon->setPixmap(grayIcon);
    // Создание горизонтального контейнера для размещения кнопки и иконки
    QHBoxLayout* layoutH = new QHBoxLayout;
    layoutH->addStretch(2);
    layoutH->addWidget( connectionStatusIcon, 0, Qt::AlignRight );
    layoutH->addWidget( button, 0, Qt::AlignRight);
    layoutV->addLayout( layoutH );
    layoutV->addWidget(tabWidget);
    centralWidget->setLayout(layoutV);
    setCentralWidget(centralWidget);
/////////////////////////////////////////////////////////////////////////////////
//    // Проверяем существует ли файл настроек
//    QString configFilePath = "config.conf";

//    // Проверяем наличие файла
//    QFile file(configFilePath);
//    if (!file.exists()) {
//        ///Создаем экземпляр класса ConfigWindow
////       ConfigWindow configWindow(this);
//     //  configWindow.createDefaultSettings(configFilePath);
//        // Файл не найден, выводим предупреждение
//        QMessageBox::warning(nullptr, "Внимание!", "Файл настроек сети не найден. Будет создан файл настроек по умолчанию! "
//                                                       "Если соединение не установлено, то требуется внести изменения в настройки конфигурации сети "
//                                                       " в меню настроек!");

//    }
//    connectDatabase = new ConnectDatabase(this);
//    connect(connectDatabase, &ConnectDatabase::databaseConnected, this, &MainWindow::updateDatabaseConnectionStatus);
//    connectDatabase->checkDatabaseConnection();
checkConfigFile();
}
MainWindow::~MainWindow()
{
}
void MainWindow::createCustomMenu()
{
    // Create File menu and actions
    QMenu *fileMenu = menuBar()->addMenu("&Файл");
/// пока оставил, может будет нужно
//    QAction *newAction = new QAction(tr("&Создать"), this);
//    fileMenu->addAction(newAction);

//    QAction *openAction = new QAction(tr("&Открыть"), this);
//    fileMenu->addAction(openAction);

//    QAction *saveAction = new QAction(tr("&Сохранить"), this);
//    fileMenu->addAction(saveAction);
    QAction *settingAction = new QAction(tr("&Настройки"), this);
    fileMenu->addAction(settingAction);

    QAction *exitAction = new QAction(("&Выход"), this);
    fileMenu->addAction(exitAction);

    // Подключаю сигнал слот
    connect(exitAction, &QAction::triggered, this, &QWidget::close);
    connect(settingAction, &QAction::triggered, this, &MainWindow::openNewWindow);
}

/// отображение нового окна, ныряем в ConfigWindow (обновляем данные если данные обновились запускаем updateConnection
void MainWindow::openNewWindow()
{
    configWindow = new ConfigWindow(this);
    connect(configWindow, &ConfigWindow::settingsSaved, this, &MainWindow::updateConnection, Qt::QueuedConnection);
    connect(configWindow, &ConfigWindow::aboutToClose, configWindow, &ConfigWindow::closeWindow);
    configWindow->exec();
}

/// Обновление подключения к базе данных (запускаем базу данных через проверку checkDatabaseConnection
/// затем checkDatabaseConnection через connected запускаем проверку updateDatabaseConnectionStatus(bool connected) и меняем цвет иконки
///  затем мы у финиша-  проверка завершена, статус установлен, приходим в конец конструктора )
void MainWindow::updateConnection()
{
    connectDatabase->checkDatabaseConnection(); // Обновление подключения к базе данных
}
// смена статусов подключения
void MainWindow::updateDatabaseConnectionStatus(bool connected)
{
    if (connected) {
            QPixmap greenIcon(":/images/images/green.png"); // Путь к изображению зеленой иконки
            connectionStatusIcon->setPixmap(greenIcon);
        } else {
            QPixmap redIcon(":/images/images/red.png"); // Путь к изображению красной иконки
            connectionStatusIcon->setPixmap(redIcon);
        }

}
// Закрываем базу данных при закрытии главного окна
void MainWindow::closeWindowCloseDbConnection()
{
    // Закрытие соединения с базой данных
    QSqlDatabase::database().close();
    QSqlDatabase::removeDatabase(QSqlDatabase::defaultConnection);
}
  // закрытие соединения с базой
void MainWindow::closeEvent(QCloseEvent *event)
{
    closeWindowCloseDbConnection();
    QMainWindow::closeEvent(event);
}
// Проверяем существует ли файл настроек
void MainWindow::checkConfigFile()
{
    QString configFilePath = "config.conf";

    // Проверяем наличие файла
    QFile file(configFilePath);
    if (!file.exists()) {
        configWindow->createDefaultSettings(configFilePath);
        QMessageBox::warning(nullptr, "Внимание!", "Файл настроек сети не найден. Будет создан файл настроек по умолчанию! "
                                                       "Если соединение не установлено, то требуется внести изменения в настройки конфигурации сети "
                                                       " в меню настроек!");

    }
    connectDatabase = new ConnectDatabase(this);
    connect(connectDatabase, &ConnectDatabase::databaseConnected, this, &MainWindow::updateDatabaseConnectionStatus);
    connectDatabase->checkDatabaseConnection();

}
