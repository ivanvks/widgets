#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QTabWidget>
#include <QPushButton>
#include <QLabel>
#include "connectdatabase.h"
#include "configwindow.h"

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void checkConfigFile();
    void createCustomMenu();
protected:
    void closeEvent(QCloseEvent *event) override;

private slots:
    void openNewWindow();
    void updateDatabaseConnectionStatus(bool connected);
    void updateConnection(); // Новый слот для сохранения настроек
    void closeWindowCloseDbConnection();


private:
    QTabWidget *tabWidget;
    QPushButton *button;
    QLabel* connectionStatusIcon;
    ConnectDatabase *connectDatabase;
    ConfigWindow *configWindow;

};
#endif // MAINWINDOW_H
